@echo off
setlocal
cd /d "%~dp0"
title MTH-A - Iniciar sistema
if exist ".venv\Scripts\python.exe" goto check
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys; assert sys.version_info >= (3,11)" >nul 2>nul
  if not errorlevel 1 (
    py -3 -m venv .venv >instalacion.log 2>&1
    goto venvmade
  )
)
where python >nul 2>nul
if not errorlevel 1 (
  python -c "import sys; assert sys.version_info >= (3,11)" >nul 2>nul
  if not errorlevel 1 (
    python -m venv .venv >instalacion.log 2>&1
    goto venvmade
  )
)
echo Necesitas instalar Python de 64 bits, version 3.12 o 3.13.
echo En el instalador marca Add python.exe to PATH.
echo Luego volve a abrir este archivo. Sitio oficial: https://www.python.org/downloads/windows/
goto end
:venvmade
if not exist ".venv\Scripts\python.exe" goto fail
:check
".venv\Scripts\python.exe" -c "import numpy, scipy, simpy" >nul 2>nul
if not errorlevel 1 goto run
echo Preparando las librerias. La primera vez necesita Internet y puede tardar.
".venv\Scripts\python.exe" -m pip install -r requirements.txt >>instalacion.log 2>&1
if errorlevel 1 goto fail
:run
echo Abriendo pantalla. Deja esta ventana abierta mientras usas el sistema.
".venv\Scripts\python.exe" sistema.py
if errorlevel 1 goto fail
goto end
:fail
echo No se pudo iniciar. Revisa instalacion.log en esta carpeta.
echo Comparti ese archivo o una captura para diagnosticar el problema.
:end
pause
