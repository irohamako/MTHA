"""Servidor local de interfaz; sólo escucha en esta computadora."""
import json,sys,subprocess,threading,webbrowser,secrets,math,zipfile,io
from pathlib import Path
from datetime import datetime
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
ROOT=Path(__file__).resolve().parent
TOKEN=secrets.token_urlsafe(24)
DEFAULT={'replicas':3,'semilla':20260925,'politica':'H70','demanda':100,'proveedor':5,'precio':13000,'materiales':100,'energia':100,'tasa':10,'remanente':100,'servicios':1309060,'equipos':85840,'contingencia':15,'soporte':32190,'cobro':45,'pago':30}
LIMITS={'replicas':(1,100),'semilla':(0,4294967295),'demanda':(10,200),'proveedor':(0,30),'precio':(1,100000),'materiales':(1,300),'energia':(1,300),'tasa':(0,100),'remanente':(0,100),'servicios':(0,1e9),'equipos':(0,1e9),'contingencia':(0,100),'soporte':(0,1e8),'cobro':(0,60),'pago':(0,60)}
state={'estado':'listo','avance':0,'total':0};lock=threading.Lock();process=None;folder=None

def validate(data):
    p={}
    for k,(lo,hi) in LIMITS.items():
        v=float(str(data.get(k,'')).replace(',','.'))
        if not math.isfinite(v) or not lo<=v<=hi:raise ValueError(f'{k}: el valor debe estar entre {lo:g} y {hi:g}.')
        if k in ('replicas','semilla'):
            if not v.is_integer():raise ValueError(f'{k}: use un número entero.')
            v=int(v)
        p[k]=v
    p['politica']=data.get('politica')
    if p['politica'] not in ('H70','H50','H30'):raise ValueError('Seleccione una política válida.')
    return p

def monitor(proc,dest):
    global state
    with (dest/'diagnostico.txt').open('w',encoding='utf-8') as log:
        for line in proc.stdout:
            log.write(line);log.flush()
            try:
                msg=json.loads(line)
                if 'avance' in msg:
                    with lock:
                        if proc is process and state["estado"]=="ejecutando":state.update(msg)
            except (ValueError,TypeError):pass
    code=proc.wait()
    with lock:
        if proc is not process or state['estado']=='cancelado':return
        if code==0 and (dest/'resumen.json').exists():
            state.update(estado='terminado',resultado=json.loads((dest/'resumen.json').read_text(encoding='utf-8')))
        else:state.update(estado='error',mensaje='No se pudo completar. Descargá el diagnóstico y compartilo para revisar el error.')

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def respond(self,obj,code=200,kind='application/json; charset=utf-8',attachment=None):
        b=json.dumps(obj,ensure_ascii=False).encode() if kind.startswith('application/json') else obj
        self.send_response(code);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(b)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        if attachment:self.send_header('Content-Disposition',f'attachment; filename="{attachment}"')
        self.end_headers();self.wfile.write(b)
    def do_GET(self):
        if self.path=='/':return self.respond((ROOT/'pantalla.html').read_text(encoding='utf-8').replace('__TOKEN__',TOKEN).encode(),kind='text/html; charset=utf-8')
        if self.path=='/estado':
            with lock:return self.respond({**state,'predeterminados':DEFAULT})
        if self.path=='/descargar' and folder:
            if state['estado']=='ejecutando':return self.respond({'error':'Esperá que termine la corrida.'},409)
            buff=io.BytesIO()
            with zipfile.ZipFile(buff,'w',zipfile.ZIP_DEFLATED) as z:
                for f in folder.iterdir():
                    if f.is_file():z.write(f,f.name)
            return self.respond(buff.getvalue(),kind='application/zip',attachment=folder.name+'.zip')
        return self.respond({'error':'No encontrado'},404)
    def do_POST(self):
        global process,folder,state
        if self.headers.get('X-MTHA-Token')!=TOKEN:return self.respond({'error':'Sesión inválida. Recargá la pantalla.'},403)
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length>10000:raise ValueError('Solicitud demasiado grande.')
            data=json.loads(self.rfile.read(length))
            with lock:
                if self.path=='/cancelar':
                    if process and process.poll() is None:state['estado']='cancelado';process.terminate()
                    return self.respond({'ok':True})
                if self.path!='/ejecutar':return self.respond({'error':'No encontrado'},404)
                if state['estado']=='ejecutando':return self.respond({'error':'Ya hay una simulación en curso.'},409)
                p=validate(data)
                folder=ROOT/'mis_resultados'/datetime.now().strftime('%Y%m%d_%H%M%S_%f');folder.mkdir(parents=True)
                (folder/'entradas.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
                process=subprocess.Popen([sys.executable,'-u',str(ROOT/'trabajo.py'),str(folder)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',cwd=ROOT)
                state={'estado':'ejecutando','avance':0,'total':p['replicas'],'carpeta':str(folder)}
                threading.Thread(target=monitor,args=(process,folder),daemon=True).start()
                return self.respond({'ok':True})
        except (ValueError,TypeError,OSError) as ex:return self.respond({'error':str(ex)},400)

if __name__=='__main__':
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    url=f'http://127.0.0.1:{server.server_port}'
    print('MTH-A abierto en '+url,flush=True)
    print('Dejá esta ventana abierta. Para salir, cerrala o presioná Ctrl+C.',flush=True)
    if '--sin-navegador' not in sys.argv:webbrowser.open(url)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:
        if process and process.poll() is None:process.terminate()
        server.server_close()
