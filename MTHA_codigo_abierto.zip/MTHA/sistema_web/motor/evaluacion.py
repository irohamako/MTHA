"""Evaluación económica del experimento MTH-A. Importes constantes de marzo 2025.

La demanda y la lógica base se conservan. El valor remanente es una hipótesis
de cierre, separada del efectivo cobrado. Ejecutar: python evaluacion.py
"""
from pathlib import Path
import sys, json, copy, math, csv, gzip, hashlib, argparse
from datetime import datetime, timedelta
import numpy as np
from scipy.stats import t as student
from concurrent.futures import ProcessPoolExecutor
sys.path.insert(0,str(Path(__file__).parent/'nucleo'))
from modelo import Modelo, EPS
from demanda import generar

ROOT=Path(__file__).parent
C=json.loads((ROOT/'configuracion_operativa.json').read_text())
P=json.loads((ROOT/'parametros_economicos_previos.json').read_text())
START=datetime(2025,3,1)
DATES=[datetime(2025,3,1)]+[datetime(2025+(m>12),(m-1)%12+1,1) for m in range(4,17)]
BOUNDS=np.array([(d-START).total_seconds()/3600 for d in DATES])
MONTHS=[d.strftime('%Y-%m') for d in DATES[:-1]]
NMONTH=len(MONTHS)
PLAN={
 'version':'1.0.0','n':100,'seed':20260925,'holdout_seed':2026092801,
 'real_rate':.10,'residual_fraction':1.,'marginal_tax':.35,
 'implementation_services':1309060.,'implementation_assets':85840.,
 'contingency_fraction':.15,'support_monthly':32190.,
 'holding_monthly':0.,'dso_days':45,'dpo_days':30,
 'price_factor':1.,'material_factor':1.,'energy_factor':1.,
 'provenance':'Presupuesto de investigación; los costos nuevos no son cotizaciones ni testimonios empresariales.',
 'closure':'Diez meses de demanda, treinta días de atención de pendientes, cobros y pagos hasta marzo 2026. Valor remanente neto de realización supuesto, separado de caja.',
 'tax':'VAN principal antes de Ganancias; ajuste marginal de 35% separado, sujeto a aprovechamiento fiscal. IVA y tributo bancario parcial sí incluidos en caja.'
}

class ModeloAmpliado(Modelo):
    """Sólo añade una demora EXTRA de cambio de grupo si se solicita.
    No sustituye ni desagrega las pérdidas contenidas en el ritmo neto previo.
    """
    def decidir(self):
        extra=self.c.get('demora_adicional_cambio_h',0.)
        if not extra:return super().decidir()
        t=self.env.now
        if self.ocupado or t>=self.fin-EPS:return
        if self.wip_inicial:
            g=self.wip_inicial[0];gid=g['id'];q=g['initial_wip'];modo='WIP inicial'
            proceso=q*self.p['wip_remaining_fraction']/self.p['net_rate']
        else:
            candidatos=[]
            for i,g in enumerate(self.grupos):
                gid=g['id'];ip=self.posicion(gid);mts=gid in self.mts
                objetivo=self.objetivos[gid] if mts and t<self.h else 0
                if objetivo-ip<=EPS:continue
                due=min((o['due'] for o in self.abiertos(gid)),default=float('inf'))
                media=self.p['monthly_demand']/self.p['days']*g['share']
                cobertura=(self.stock(gid)-sum(o['qty'] for o in self.abiertos(gid)))/media if media else float('inf')
                candidatos.append(((0 if ip<-EPS else 1,due if ip<-EPS else cobertura,i),gid,mts))
            if not candidatos:return
            _,gid,mts=min(candidatos);q=self.p['lot'];proceso=q/self.p['net_rate'];modo='MTS' if mts else 'MTO'
            if self.m['limitados'] and self.mp+EPS<1:return
        prep=extra if self.lotes and self.lotes[-1]['grupo']!=gid else 0.
        dur=proceso+prep
        inicio=next((max(t,a) for a,b in self.ventanas if max(t,a)+dur<=b+EPS),None)
        if inicio is None or inicio>=self.fin:return
        if inicio>t+EPS:
            if inicio not in self.despertares:self.despertares.add(inicio);self.agendar(inicio,'despertar')
            return
        if modo=='WIP inicial':self.wip_inicial.pop(0)
        else:
            self.mp-=1;self.contador['mp_consumido']+=1;self.wip[gid]+=q
            self.contador['iniciado']+=q;self.contador['iniciado_'+modo]+=q
        self.ocupado=True
        lote={'id':f'L{len(self.lotes)+1:04d}','grupo':gid,'qty':q,'modo':modo,'inicio':t,'duracion':dur,'preparacion_h':prep,'fin_proceso':None,'alta':None}
        self.lotes.append(lote);self.agendar(t+dur,'fin_proceso',lote)
        self.registrar('inicio',gid,q,lote=lote['id'],nota=modo)

def month(t):
    return int(np.searchsorted(BOUNDS[1:],t,side='right'))

def raw_run(c,policy,orders):
    mod=ModeloAmpliado(c,policy['mts_groups'],orders,True);r=mod.correr()
    lots=mod.lotes;ev=mod.eventos;h=mod.h;fin=mod.fin
    raw={'politica':policy['id'],'config':c,'resumen':r['resumen'],'meses':MONTHS,
         'flows':{},'end':{},'initial':{},'orders':[], 'receipts':[], 'packing':[]}
    names=['nuevos_m2','altas_m2','horas_proceso','horas_preparacion','recetas_consumidas','recetas_recibidas','embalado_m2','despachado_m2','entregado_m2','fg_promedio','mp_promedio','wip_material_promedio','wip_conversion_promedio','horas_disponibles','arranques','actividad']
    f={k:np.zeros(NMONTH) for k in names}
    for a,b,m in mod.meses:
        idx=month(a)
        if idx>=NMONTH:continue
        f['actividad'][idx]=max(0,min(b,fin)-a)/(b-a)
    for a,b in mod.ventanas:
        if a>=fin:continue
        k=month(a)
        if k<NMONTH:f['horas_disponibles'][k]+=max(0,min(b,fin)-a);f['arranques'][k]+=1
    for o in mod.pedidos:
        if o['dispatch'] is not None and o['dispatch']<=fin+EPS:f['despachado_m2'][month(o['dispatch'])]+=o['qty']
        if o['delivery'] is not None and o['delivery']<=fin+EPS:
            f['entregado_m2'][month(o['delivery'])]+=o['qty'];raw['orders'].append([o['delivery'],o['qty']])
    for e in ev:
        if e['evento']=='recepcion_mp':
            q=float(e['nota'].split()[0]);f['recetas_recibidas'][month(e['hora'])]+=q;raw['receipts'].append([e['hora'],q])
    for l in lots:
        a=l['inicio'];prep=l.get('preparacion_h',0.);ps=a+prep;dur=l['duracion']-prep;end=ps+dur
        if l['modo']!='WIP inicial':f['recetas_consumidas'][month(a)]+=1
        for k,(aa,bb) in enumerate(zip(BOUNDS[:-1],BOUNDS[1:])):
            f['horas_proceso'][k]+=max(0,min(bb,end,fin)-max(aa,ps))
            f['horas_preparacion'][k]+=max(0,min(bb,ps,fin)-max(aa,a))
        alta=l['alta']
        if alta is not None and alta<=fin+EPS:
            k=month(alta);f['altas_m2'][k]+=l['qty'];f['embalado_m2'][k]+=l['qty'];raw['packing'].append([alta,l['qty']])
            if l['modo']!='WIP inicial':f['nuevos_m2'][k]+=l['qty']
    # Estados físicos constantes entre eventos; el WIP se valora por avance de conversión.
    times=np.array([e['hora'] for e in ev]);states=['fg_m2','mp_lotes','wip_m2','transito_m2']
    init={'fg_m2':sum(g['initial_fg'] for g in c['grupos']),'mp_lotes':mod.mp_inicial,'wip_m2':sum(g['initial_wip'] for g in c['grupos']),'transito_m2':0.}
    init['wip_conversion']=init['wip_m2']*(1-c['parametros']['wip_remaining_fraction'])
    raw['initial']=init
    endstate={s:[] for s in states};endstate['wip_conversion']=[]
    for k,(a,b) in enumerate(zip(BOUNDS[:-1],BOUNDS[1:])):
        t=min(b,fin);cut=t-EPS if b<=fin else t+EPS
        idx=np.searchsorted(times,cut,side='right')-1
        for s in states:endstate[s].append(float(ev[idx][s]) if idx>=0 else init[s])
        conv=0.
        for l in lots:
            initial=l['modo']=='WIP inicial';birth=0. if initial else l['inicio']
            if birth>cut or (l['alta'] is not None and l['alta']<=cut):continue
            ps=l['inicio']+l.get('preparacion_h',0.);d=l['duracion']-l.get('preparacion_h',0.)
            frac=min(1,max(0,(t-ps)/d))
            conv+=l['qty']*((1-c['parametros']['wip_remaining_fraction'])+c['parametros']['wip_remaining_fraction']*frac if initial else frac)
        endstate['wip_conversion'].append(conv)
        # Exact integral of quantities with events at identical times causing zero-duration increments.
        inds=np.where((times>=a-EPS)&(times<min(b,fin)-EPS))[0]
        last=a;prev=np.searchsorted(times,a,side='right')-1
        state=ev[prev] if prev>=0 else init
        for j in inds:
            dt=max(0,times[j]-last)
            f['fg_promedio'][k]+=state['fg_m2']*dt;f['mp_promedio'][k]+=state['mp_lotes']*dt
            last=times[j];state=ev[j]
        dt=max(0,min(b,fin)-last)
        f['fg_promedio'][k]+=state['fg_m2']*dt;f['mp_promedio'][k]+=state['mp_lotes']*dt
        # After process follow-up, stocks stay unchanged pending analytical close.
        if b>fin:
            dt=b-max(a,fin);f['fg_promedio'][k]+=endstate['fg_m2'][-1]*dt;f['mp_promedio'][k]+=endstate['mp_lotes'][-1]*dt
        f['fg_promedio'][k]/=(b-a);f['mp_promedio'][k]/=(b-a)
        for l in lots:
            initial=l['modo']=='WIP inicial';birth=0. if initial else l['inicio'];alta=l['alta'] or fin
            lo=max(a,birth);hi=min(b,alta)
            if hi<=lo:continue
            q=l['qty'];ps=l['inicio']+l.get('preparacion_h',0.);pe=l['inicio']+l['duracion'];d=pe-ps
            def integral_progress(x):
                u=max(0,x-ps)
                return u*u/(2*d) if u<d else u-d/2
            prog=integral_progress(hi)-integral_progress(lo)
            f['wip_material_promedio'][k]+=q*(hi-lo)/(b-a)
            f['wip_conversion_promedio'][k]+=q*((.6*(hi-lo)+.4*prog) if initial else prog)/(b-a)
    raw['flows']={k:v.tolist() for k,v in f.items()};raw['end']=endstate
    # C9 equality is checked on physical totals, with no economic assumptions involved.
    assert abs(sum(f['nuevos_m2'][:10])-r['resumen']['produccion_m2'])<1e-5
    assert abs(sum(f['entregado_m2'][:10])-r['resumen']['entregado_m2'])<1e-5
    assert abs(sum(np.array(f['fg_promedio'][:10])*np.diff(BOUNDS)[:10])/h-r['resumen']['fg_promedio_m2'])<1e-5
    return raw

def economics(raw,updates=None):
    e={**PLAN,**(updates or {})};c=raw['config'];p=c['parametros'];f={k:np.array(v,float) for k,v in raw['flows'].items()};s={k:np.array(v,float) for k,v in raw['end'].items()}
    hybrid=raw['politica']!='MTS100';fx=P['fx'];lot=p['lot'];rate=p['net_rate']
    matlot=(3009.8+405)*fx*e['material_factor'];mat=matlot/lot;pack=.55*fx*e['material_factor']
    # Energy per gross lot stays constant when changing the net yield.
    yield_factor=900/lot;elec=6*145*e['energy_factor']*yield_factor;gas=110*7.5*fx/1055.056*e['energy_factor']*yield_factor
    maint_h=(10+500/240)*fx;water=4000/lot
    conv=elec+gas+maint_h/rate+water;vc=mat+pack+conv
    init=raw['initial'];init_inv=init['mp_lotes']*matlot+init['wip_m2']*mat+init['wip_conversion']*conv+init['fg_m2']*vc
    inv_mp=s['mp_lotes']*matlot;inv_wip=s['wip_m2']*mat+s['wip_conversion']*conv;inv_fg=s['fg_m2']*vc;inv_trans=s['transito_m2']*vc
    inv=inv_mp+inv_wip+inv_fg+inv_trans;d_inv=np.diff(np.r_[init_inv,inv])
    delivered=f['entregado_m2'];dispatch=f['despachado_m2'];produced=f['nuevos_m2'];equiv=f['horas_proceso']*rate
    revenue=delivered*P['price']*e['price_factor']*(1-P['ret'])
    material_consumed=f['recetas_consumidas']*matlot;packing=f['embalado_m2']*pack
    electricity=equiv*elec;gas_active=equiv*gas;maintenance=f['horas_proceso']*maint_h;water_cost=equiv*water
    idle=np.maximum(0,f['horas_disponibles']-f['horas_proceso'])
    gas_idle=idle*rate*gas*.1;gas_start=f['arranques']*30000*7.5*fx/1055.056*e['energy_factor']
    labor_factory=(44617496.58626064-219770.76023741934)*f['actividad'];admin=219770.76023741934*f['actividad']
    fixed_energy=483870.96774193546*f['actividad'];dep=5191935.483870967*f['actividad'];store=500000*f['actividad']
    variable_manuf=material_consumed+packing+electricity+gas_active+maintenance+water_cost
    fixed_factory=labor_factory+fixed_energy+gas_idle+gas_start+dep
    industrial=variable_manuf+fixed_factory
    freight=dispatch*P['freight']*fx;handling=dispatch*P['handle']*fx;reverse=delivered*P['ret']*P['reverse']*fx
    sales_taxes=revenue*(P['iibb']+P['municipal']);commission=revenue*P['comm']
    holding=f['fg_promedio']*vc*e['holding_monthly']
    recurring=e['support_monthly']*f['actividad'] if hybrid else np.zeros(NMONTH)
    capex=e['implementation_assets']*(1+e['contingency_fraction']) if hybrid else 0.
    dep_new=capex/36*f['actividad']
    cogs=delivered*vc
    operating=revenue-cogs-fixed_factory-admin-store-freight-handling-reverse-sales_taxes-commission-holding-recurring-dep_new
    # Net invoices and their exact 45/30 day date offsets.
    col=np.zeros(NMONTH);mp_paid=np.zeros(NMONTH);pk_paid=np.zeros(NMONTH)
    for t,q in raw['orders']:
        idx=month(t+e['dso_days']*24)
        if idx<NMONTH:col[idx]+=q*P['price']*e['price_factor']*(1-P['ret'])
    for t,q in raw['receipts']:
        idx=month(t+e['dpo_days']*24)
        if idx<NMONTH:mp_paid[idx]+=q*matlot
    for t,q in raw['packing']:
        idx=month(t+e['dpo_days']*24)
        if idx<NMONTH:pk_paid[idx]+=q*pack
    mp_invoice=f['recetas_recibidas']*matlot
    ar=np.cumsum(revenue-col);ap=np.cumsum(mp_invoice+packing-mp_paid-pk_paid)
    nct=inv+ar-ap;d_nct=np.diff(np.r_[init_inv,nct])
    energy=electricity+gas_active+gas_idle+gas_start+fixed_energy
    general_cash=maintenance+water_cost+freight+handling+reverse+commission+store+holding+recurring
    op_cash=energy+general_cash+labor_factory+admin+sales_taxes
    direct=col-mp_paid-pk_paid-op_cash
    indirect=operating+dep+dep_new-d_nct
    if max(abs(direct-indirect))>=.02:
        print('DEBUG',raw['politica'],c.get('demora_adicional_cambio_h'),p['lot'],[(MONTHS[k],round(direct[k]-indirect[k],2),s['mp_lotes'][k],f['recetas_recibidas'][k],f['recetas_consumidas'][k],s['wip_m2'][k],s['wip_conversion'][k]) for k in range(NMONTH)],flush=True)
        raise ArithmeticError(('caja',max(abs(direct-indirect))))
    # VAT is a cash bridge; recoverable VAT is never added to unit costs.
    vout=revenue*.21;vin=(mp_invoice+packing+general_cash)*.21+energy*.27
    credit=0.;due=np.zeros(NMONTH);vcredit=[]
    for k in range(NMONTH):
        balance=vout[k]-vin[k]-credit;due[k]=max(0,balance);credit=max(0,-balance);vcredit.append(credit)
    vat_payment=np.r_[0.,due[:-1]]
    vat_cash=col*.21-(mp_paid+pk_paid+general_cash)*.21-energy*.27-vat_payment
    # Partial conservative banking levy: modeled operating movements, excluding levy itself, income tax and transition.
    gross_payment=(mp_paid+pk_paid+general_cash)*1.21+energy*1.27+labor_factory+admin+sales_taxes+vat_payment
    bank=P['bank']*(col*1.21+gross_payment)
    cf=direct+vat_cash-bank
    cash_setup=(e['implementation_services']+e['implementation_assets'])*(1+e['contingency_fraction']) if hybrid else 0.
    # Setup budget is all-in cash; no unverified input VAT tax benefit is taken.
    setup_expense=e['implementation_services']*(1+e['contingency_fraction']) if hybrid else 0.
    terminal=inv[-1]*e['residual_fraction']
    values=np.r_[-cash_setup,cf];values[-1]+=terminal
    rm=(1+e['real_rate'])**(1/12)-1
    npv=float(np.sum(values/(1+rm)**np.arange(NMONTH+1)))
    # Conditional equivalent income-tax charge, not a reconstructed tax return.
    taxable=operating-bank
    taxable[0]-=setup_expense
    tax=e['marginal_tax']*taxable
    tax_cash=np.r_[0.,tax[:-1]]
    tax_cash[-1]+=tax[-1]+e['marginal_tax']*(terminal-inv[-1])
    values_tax=values-np.r_[0.,tax_cash]
    npv_tax=float(np.sum(values_tax/(1+rm)**np.arange(NMONTH+1)))
    m={**f,'material_consumido':material_consumed,'embalaje':packing,'electricidad':electricity,'gas_proceso':gas_active,'gas_espera':gas_idle,'gas_arranque':gas_start,'mantenimiento':maintenance,'agua':water_cost,'personal_fabril':labor_factory,'energia_fija':fixed_energy,'depreciacion':dep,'costo_industrial':industrial,'ventas_netas':revenue,'costo_ventas_variable':cogs,'costos_fijos_fabriles':fixed_factory,'administracion':admin,'deposito':store,'flete':freight,'manipulacion':handling,'devoluciones':reverse,'tributos_ventas':sales_taxes,'comisiones':commission,'tenencia_variable':holding,'soporte_mtha':recurring,'resultado_operativo':operating,'inv_mp':inv_mp,'inv_wip':inv_wip,'inv_fg':inv_fg,'inv_transito':inv_trans,'inv_total':inv,'cxc':ar,'cxp':ap,'nct':nct,'variacion_nct':d_nct,'cobros':col,'compras_mp':mp_invoice,'pagos_mp':mp_paid,'pagos_envases':pk_paid,'otros_pagos_netos':op_cash,'caja_neta_operativa':direct,'iva_debito':vout,'iva_credito_compras':vin,'iva_credito_saldo':np.array(vcredit),'iva_pago':vat_payment,'puente_iva':vat_cash,'impuesto_bancario_parcial':bank,'flujo_antes_ganancias':cf,'impuesto_ganancias_equivalente':tax_cash}
    m['depreciacion_implementacion']=dep_new
    initial_wip=init['wip_m2']*mat+init['wip_conversion']*conv
    cost_completed=sum(industrial[:10])+initial_wip-inv_wip[9]
    metrics={**raw['resumen'],'costo_variable_unitario':vc,'material_unitario':mat,'embalaje_unitario':pack,'conversion_unitaria':conv,
             'inversion_inicial':cash_setup,'valor_remanente':terminal,'van_pre_ganancias':npv,'van_condicional_post_ganancias':npv_tax,
             'costo_industrial_10m':sum(industrial[:10]),'ventas_10m':sum(revenue[:10]),'costo_ventas_variable_10m':sum(cogs[:10]),
             'resultado_operativo_10m':sum(operating[:10]),'resultado_tras_banco_10m':sum((operating-bank)[:10]),
             'costo_altas_10m':cost_completed,
             'costo_por_m2_completado':cost_completed/sum(f['altas_m2'][:10]) if sum(f['altas_m2'][:10]) else None,
             'nct_diciembre':nct[9],'inv_diciembre':inv[9],
             'inv_fg_promedio_variable':np.average(f['fg_promedio'][:10]*vc,weights=np.diff(BOUNDS)[:10]),
             'inv_mp_promedio':np.average(f['mp_promedio'][:10]*matlot,weights=np.diff(BOUNDS)[:10]),
             'inv_wip_promedio':np.average(f['wip_material_promedio'][:10]*mat+f['wip_conversion_promedio'][:10]*conv,weights=np.diff(BOUNDS)[:10]),
             'saldo_cxc_final':ar[-1],'saldo_cxp_final':ap[-1],
             'balance_caja_max':float(max(abs(direct-indirect)))}
    return {'metricas':metrics,'mensual':{k:v.tolist() for k,v in m.items()},'flujo_valorado':values.tolist(),'flujo_post_equivalente':values_tax.tolist(),'inicial_inventario':init_inv,'supuestos':e}

def ci(x):
    x=np.asarray(x,float);mean=float(x.mean());half=float(student.ppf(.975,len(x)-1)*x.std(ddof=1)/math.sqrt(len(x))) if len(x)>1 else 0
    return {'media':mean,'inferior':mean-half,'superior':mean+half,'semiancho':half,'n':len(x)}

def csvwrite(path,rows):
    if not rows:return
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def one_pair(args):
    name,c,i,seed,policies,updates=args
    orders=generar(c,seed,i);result=[]
    for policy in policies:
        raw=raw_run(c,policy,orders);econ=economics(raw,updates)
        result.append((policy,raw,econ))
    return i,result

def save_case(name,results,out):
    rows=[];monthly=[];detailed=[]
    for i,result in results:
        for policy,raw,econ in result:
            rows.append({'escenario':name,'politica':policy['id'],'replica':i+1,**econ['metricas']})
            for j,mo in enumerate(MONTHS):monthly.append({'escenario':name,'politica':policy['id'],'replica':i+1,'mes':mo,**{k:v[j] for k,v in econ['mensual'].items()}})
            detailed.append({'replica':i+1,'raw':raw})
            if i==0:(out/f'ejemplo_{name}_{policy["id"]}.json').write_text(json.dumps(econ,ensure_ascii=False,indent=2))
    csvwrite(out/f'replicas_{name}.csv',rows);csvwrite(out/f'mensual_{name}.csv',monthly)
    return rows,monthly,detailed

def run_case(name,c,n,seed,policies,updates,out,workers=4,revalue=False):
    if revalue:
        raw=json.loads(gzip.open(out/f'fisico_{name}.json.gz','rt',encoding='utf8').read())
        if any(item['raw']['config']!=c for item in raw):
            raise ValueError('Cambió una condición física. Ejecute nuevamente sin --revalorar.')
        if len({item['replica'] for item in raw})!=n:
            raise ValueError('La cantidad de réplicas conservadas no coincide con el protocolo.')
        groups={}
        for item in raw:
            i=item['replica']-1;r=item['raw']
            groups.setdefault(i,[]).append(({'id':r['politica']},r,economics(r,updates)))
        return save_case(name,groups.items(),out)
    rows=[];monthly=[];detailed=[]
    with ProcessPoolExecutor(max_workers=workers) as pool:
      for i,result in pool.map(one_pair,[(name,c,i,seed,policies,updates) for i in range(n)]):
        for policy,raw,econ in result:
            rows.append({'escenario':name,'politica':policy['id'],'replica':i+1,**econ['metricas']})
            for j,mo in enumerate(MONTHS):monthly.append({'escenario':name,'politica':policy['id'],'replica':i+1,'mes':mo,**{k:v[j] for k,v in econ['mensual'].items()}})
            detailed.append({'replica':i+1,'raw':raw})
            if i==0:(out/f'ejemplo_{name}_{policy["id"]}.json').write_text(json.dumps(econ,ensure_ascii=False,indent=2))
        if (i+1)%25==0:print(name,i+1,flush=True)
    with gzip.open(out/f'fisico_{name}.json.gz','wt',encoding='utf8') as f:json.dump(detailed,f)
    csvwrite(out/f'replicas_{name}.csv',rows);csvwrite(out/f'mensual_{name}.csv',monthly)
    return rows,monthly,detailed

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--rapido',action='store_true');parser.add_argument('--revalorar',action='store_true');args=parser.parse_args()
    out=ROOT/('resultados_prueba' if args.rapido else 'resultados');out.mkdir(exist_ok=True);n=3 if args.rapido else PLAN['n']
    (out/'protocolo_economico.json').write_text(json.dumps({**PLAN,'n':n},ensure_ascii=False,indent=2))
    scenarios=[('base',{},{}),('demanda_80',{'demand':.8},{}),('demanda_120',{'demand':1.2},{}),
        ('dispersion_25',{'sd':162.5},{}),('dispersion_100',{'sd':650},{}),
        ('proveedor_10',{'supplier':10},{}),('cambio_extra_1h',{'prep':1},{}),
        ('rendimiento_85',{'yield':.85},{}),('rendimiento_95',{'yield':.95},{}),
        ('capacidad_144',{'windows':[[0,48],[240,288],[480,528]]},{}),
        ('ventana_240',{'windows':[[0,240]]},{}),
        ('tension_demanda_costos',{'demand':.8,'supplier':10,'windows':[[0,48],[240,288],[480,528]]},{'material_factor':1.15,'energy_factor':1.2,'price_factor':.9}),
        ('tension_crecimiento',{'demand':1.2,'sd':487.5,'prep':1},{'material_factor':1.1,'energy_factor':1.15}),
        ('comprobacion_independiente',{}, {})]
    allrows=[];allmonths=[];base_raw=None;summary={};pairs=[];summonth=[]
    for name,changes,updates in scenarios:
        c=copy.deepcopy(C)
        if 'demand' in changes:
            for m in c['demanda_mensual']:m['m2']*=changes['demand']
            c['parametros']['monthly_demand']*=changes['demand']
        if 'sd' in changes:c['parametros']['order_sd']=changes['sd']
        if 'supplier' in changes:c['materiales']['plazo_dias']=changes['supplier']
        if 'windows' in changes:c['ventanas']=changes['windows']
        if 'prep' in changes:c['demora_adicional_cambio_h']=changes['prep']
        if 'yield' in changes:
            c['parametros']['lot']=1000*changes['yield'];c['parametros']['net_rate']=C['parametros']['net_rate']*changes['yield']/.9
        pols=c['politicas'] if name=='base' else c['politicas'][:2]
        seed=PLAN['holdout_seed'] if name=='comprobacion_independiente' else PLAN['seed']
        rows,months,raw=run_case(name,c,n,seed,pols,updates,out,revalue=args.revalorar)
        if name=='base':base_raw=raw
        allrows+=rows;allmonths+=months
        summary[name]={}
        for pol in pols:
            pr=[x for x in rows if x['politica']==pol['id']]
            summary[name][pol['id']]={k:ci([v[k] for v in pr]) for k in pr[0] if isinstance(pr[0][k],(float,int)) and pr[0][k] is not None}
            for mo in MONTHS:
                vals=[x for x in months if x['politica']==pol['id'] and x['mes']==mo]
                summonth.append({'escenario':name,'politica':pol['id'],'mes':mo,**{k:float(np.mean([v[k] for v in vals])) for k in vals[0] if isinstance(vals[0][k],(float,int))}})
        for pol in pols[1:]:
            a=[x for x in rows if x['politica']==pol['id']];b=[x for x in rows if x['politica']=='MTS100']
            for key in ['van_pre_ganancias','van_condicional_post_ganancias','fg_promedio_m2','otif_pct','lead_dias','resultado_operativo_10m','nct_diciembre']:
                pairs.append({'escenario':name,'politica':pol['id'],'indicador':key,**ci([x[key]-y[key] for x,y in zip(a,b)])})
    # Financial one-at-a-time changes keep each existing physical realization intact.
    financial=[('precio_10000',{'price_factor':10000/13000}),('precio_16000',{'price_factor':16000/13000}),
        ('energia_80',{'energy_factor':.8}),('energia_120',{'energy_factor':1.2}),
        ('materiales_85',{'material_factor':.85}),('materiales_115',{'material_factor':1.15}),
        ('cobro_30',{'dso_days':30}),('cobro_60',{'dso_days':60}),
        ('tenencia_02',{'holding_monthly':.002}),('tasa_05',{'real_rate':.05}),('tasa_20',{'real_rate':.20}),
        ('remanente_80',{'residual_fraction':.8}),('remanente_0',{'residual_fraction':0}),
        ('implementacion_50',{'implementation_services':PLAN['implementation_services']*.5,'implementation_assets':PLAN['implementation_assets']*.5}),
        ('implementacion_150',{'implementation_services':PLAN['implementation_services']*1.5,'implementation_assets':PLAN['implementation_assets']*1.5}),
        ('implementacion_ampliada',{'implementation_services':4800000.,'implementation_assets':1800000.,'contingency_fraction':.1,'support_monthly':250000.})]
    finrows=[]
    for name,change in financial:
        aa=[];bb=[]
        for item in base_raw:
            if item['raw']['politica'] not in ('MTS100','H70'):continue
            x=economics(item['raw'],change)
            (aa if item['raw']['politica']=='H70' else bb).append(x['metricas']['van_pre_ganancias'])
        finrows.append({'escenario':name,**ci(np.array(aa)-np.array(bb))})
    # A map uses physical base data and recalculates its cash flows, not a chart-only multiplier.
    maprows=[]
    for holding in [0,.002,.005,.01]:
        for residual in [0,.5,.8,1.]:
            aa=[];bb=[]
            for item in base_raw:
                if item['raw']['politica'] not in ('MTS100','H70'):continue
                x=economics(item['raw'],{'holding_monthly':holding,'residual_fraction':residual})
                (aa if item['raw']['politica']=='H70' else bb).append(x['metricas']['van_pre_ganancias'])
            maprows.append({'tenencia_mensual':holding,'fraccion_remanente':residual,**ci(np.array(aa)-np.array(bb))})
    csvwrite(out/'resumen_mensual.csv',summonth);csvwrite(out/'diferencias_pareadas.csv',pairs)
    csvwrite(out/'sensibilidad_financiera.csv',finrows);csvwrite(out/'mapa_viabilidad.csv',maprows)
    (out/'resumen.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
    checks={'max_error_caja':max(x['balance_caja_max'] for x in allrows),'n_ejecuciones_operativas':len(allrows),'n_pares_base':n,'semilla_final':PLAN['seed'],'semilla_independiente':PLAN['holdout_seed']}
    (out/'comprobaciones.json').write_text(json.dumps(checks,indent=2))
    print(json.dumps(checks),flush=True)

if __name__=='__main__':main()
