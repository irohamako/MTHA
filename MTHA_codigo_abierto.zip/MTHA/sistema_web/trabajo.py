"""Adaptador de interfaz. Conserva el motor económico original."""
import sys,json,copy,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'motor'))

def ejecutar(folder):
    import evaluacion as e
    p=json.loads((folder/'entradas.json').read_text(encoding='utf-8'))
    c=copy.deepcopy(e.C)
    for m in c['demanda_mensual']:m['m2']*=p['demanda']/100
    c['parametros']['monthly_demand']*=p['demanda']/100
    c['materiales']['plazo_dias']=p['proveedor']
    updates={'real_rate':p['tasa']/100,'residual_fraction':p['remanente']/100,
      'price_factor':p['precio']/e.P['price'],'material_factor':p['materiales']/100,
      'energy_factor':p['energia']/100,'implementation_services':p['servicios'],
      'implementation_assets':p['equipos'],'contingency_fraction':p['contingencia']/100,
      'support_monthly':p['soporte'],'dso_days':p['cobro'],'dpo_days':p['pago']}
    policies=[c['politicas'][0],next(x for x in c['politicas'] if x['id']==p['politica'])]
    (folder/'configuracion_ejecutada.json').write_text(json.dumps({'operacion':c,'economia':{**e.PLAN,**updates},'semilla':p['semilla'],'replicas':p['replicas']},ensure_ascii=False,indent=2),encoding='utf-8')
    rows=[];monthly=[];diff=[];flows=[]
    for i in range(p['replicas']):
        _,rs=e.one_pair(('interfaz',c,i,p['semilla'],policies,updates))
        for policy,raw,econ in rs:
            rows.append({'politica':policy['id'],'replica':i+1,**econ['metricas']})
            for j,mo in enumerate(e.MONTHS):monthly.append({'politica':policy['id'],'replica':i+1,'mes':mo,**{k:v[j] for k,v in econ['mensual'].items()}})
        a=rs[0][2];b=rs[1][2]
        diff.append(b['metricas']['van_pre_ganancias']-a['metricas']['van_pre_ganancias'])
        flows.append([y-x for x,y in zip(a['flujo_valorado'],b['flujo_valorado'])])
        print(json.dumps({'avance':i+1,'total':p['replicas']}),flush=True)
    e.csvwrite(folder/'resultados_por_replica.csv',rows);e.csvwrite(folder/'resultados_mensuales.csv',monthly)
    keys=['fg_promedio_m2','otif_pct','lead_dias','resultado_operativo_10m','nct_diciembre','costo_industrial_10m']
    av={pol['id']:{k:sum(r[k] for r in rows if r['politica']==pol['id'])/p['replicas'] for k in keys} for pol in policies}
    meanflow=[sum(v[k] for v in flows)/len(flows) for k in range(len(flows[0]))]
    inv=(p['servicios']+p['equipos'])*(1+p['contingencia']/100)
    result={'replicas':p['replicas'],'semilla':p['semilla'],'politica':p['politica'],'van':e.ci(diff),'medias':av,
      'flujo_incremental':meanflow,'roi':sum(meanflow)/inv*100 if inv else None,
      'pares_negativos':sum(v<0 for v in diff),'error_balance':max(r['balance_caja_max'] for r in rows)}
    (folder/'resumen.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'terminado':True}),flush=True)

if __name__=='__main__':
    try:ejecutar(Path(sys.argv[1]))
    except Exception:
        traceback.print_exc();sys.exit(1)
