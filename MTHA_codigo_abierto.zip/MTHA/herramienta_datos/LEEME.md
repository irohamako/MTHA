# MTH-A 01 — datos por familia

Primera entrega de la secuencia **datos → diagnóstico → simulación → escenarios**.

## Primero, leé la guía

Abrí `docs/GUIA_DATOS_Y_USO.html` con el navegador. Contiene qué datos buscar, dónde conseguirlos, cómo definir las familias, qué columnas completar y cómo interpretar cada cálculo.

## Abrir el programa

1. Extraé TODO el ZIP en una carpeta de tu computadora. No ejecutes desde dentro del ZIP.
2. Necesitás Python **3.10 o posterior** instalado. Esta versión se probó en Python 3.12. No requiere instalar paquetes con pip ni registrarse en servicios.
3. Windows: doble clic en `INICIAR_WINDOWS.bat`. Si no tenés Python, instalalo desde https://www.python.org/downloads/ y volvé a abrir el archivo.
4. Mac/Linux: abrí una terminal dentro de la carpeta y ejecutá `python3 app.py`.
5. Se abre el navegador en `http://127.0.0.1:8765`. Dejá abierta la ventana de Python. Para terminar, Ctrl+C en esa ventana.

Si el navegador no se abre, copiá esa dirección manualmente. Si el puerto está ocupado: `python app.py --port 8766` (o `python3` en Mac/Linux).

El cálculo corre en tu computadora. Este programa no sube datos a Internet. Es una aplicación local; no está preparada para publicarse como servidor web. En iPhone podés leer la guía, pero el programa necesita una computadora con Python.

## Primera prueba

1. Presioná **Probar con familias A y B**.
2. Observá las cuatro matrices y el período 2025-01 a 2025-12.
3. Presioná **Calcular y comparar**.
4. Cambiá un número de demanda y volvé a calcular. Al editar, los resultados anteriores se invalidan.
5. Presioná **Descargar resultados para compartir**. Ese ZIP reúne las entradas y los resultados para compartirlos o archivarlos. El programa guarda otra copia dentro de `resultados`.

Los valores del ejemplo son sintéticos. No representan familias ni mediciones de ILVA.

## Cargar tus datos

Las dos primeras tablas habilitan demanda media, desviación y CV. Inventario y parámetros son opcionales para empezar; sus indicadores quedan vacíos si faltan datos.

- `FAMILIAS.csv`: una fila por familia.
- `DEMANDA.csv`: una fila por familia y mes.
- `INVENTARIO.csv`: una fila por familia y mes.
- `PARAMETROS_MTHA.csv`: una fila por familia y parámetro. Podés copiar `CATALOGO_PARAMETROS.csv`, cambiar el ID y completar lo conocido.

Abrí las plantillas con Excel o Sheets; conservá los encabezados. En Excel, importá los CSV desde Datos → Desde texto/CSV y elegí punto y coma. Después guardá como CSV UTF-8 o copiá toda la tabla, incluidos encabezados, y pegala en el recuadro del programa. La interfaz acepta separadores `;`, coma o tabulación, y decimales con coma o punto **sin separadores de miles**. `1.234` significa 1,234 unidades decimales, no mil doscientos treinta y cuatro; escribí `1234` para evitar ambigüedad.

No carga XLSX directamente. Exportalo a CSV o pegá sus celdas. Los IDs deben coincidir exactamente en todas las tablas. Si el código tiene ceros iniciales, guardalo como texto en la planilla.

**Guardá proyecto** descarga un JSON con todas las tablas, incluso borradores incompletos. **Abrir proyecto guardado** recupera ese JSON. No hay autoguardado de las ediciones: guardá antes de cerrar. Cada exportación de resultados conserva una copia de las entradas y su huella SHA256; para reemplazar parámetros, guardá una versión previa y editá el valor/fuente/tipo en una copia.

## Qué devuelve y qué queda para después

Devuelve estadísticas de demanda, tamaño medio de pedido, inventario promedio, cobertura, rotación del período, capital promedio, costo anual equivalente de mantenimiento, carga demanda/capacidad y holgura de plazo MTO sin cola. Incluye trazabilidad y una lista de faltantes por familia.

Esta entrega **no ejecuta simulaciones de eventos discretos**, no calcula OTIF/fill rate desde totales mensuales, no dimensiona stock de seguridad con una desviación diaria inventada y no recomienda automáticamente 70/30. El paso siguiente será seleccionar una familia con tus datos y agregar el simulador con órdenes, recursos, colas y escenarios.

## Reproducir sin interfaz

```bash
python calcular.py ejemplo/PROYECTO_EJEMPLO.json --salida resultados/MI_PRUEBA.zip
python -m unittest discover -s tests -v
```

## Archivos del código

- `app.py`: interfaz HTTP local y exportación de resultados.
- `mtha/analisis.py`: validación, cálculos y normalización reversible.
- `web/`: interfaz HTML/CSS/JavaScript, sin dependencias externas.
- `calcular.py`: cálculo desde un proyecto JSON.
- `generar_ejemplo.py`: regenera plantillas y ejemplos, sin tocar tus proyectos.
- `tests/`: comprobaciones de fórmulas, casos extremos e intercambio de archivos.
- `docs/`: guía, fórmulas, fuentes y registro de verificación.

Python 3.10+ · Biblioteca estándar · Sin pip · Versión 1.0.0
