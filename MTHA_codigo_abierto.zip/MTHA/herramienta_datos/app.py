#!/usr/bin/env python3
"""Interfaz local MTH-A. Ejecutar: python app.py"""
import argparse
import io
import json
import secrets
import threading
import webbrowser
import zipfile
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from mtha.analisis import InputError, PARAMS, SCHEMAS, analyze, csv_text

ROOT = Path(__file__).resolve().parent


def load_example():
    return json.loads((ROOT / "ejemplo" / "PROYECTO_EJEMPLO.json").read_text(encoding="utf-8"))


def export_zip(payload, result):
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("PROYECTO.json", json.dumps(payload, ensure_ascii=False, indent=2))
        z.writestr("RESULTADOS.json", json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
        for name, key in [("RESULTADOS_FAMILIAS", "resultados"), ("DATOS_FALTANTES", "faltantes"), ("SERIES_MENSUALES", "series"), ("TRAZABILIDAD_DATOS", "trazabilidad")]:
            rows = result[key]
            columns = list(dict.fromkeys(k for r in rows for k in r))
            z.writestr(name + ".csv", csv_text(rows, columns))
        for name in SCHEMAS:
            z.writestr("entradas/" + name + ".csv", payload["tables"].get(name, ""))
        z.writestr("LEEME.txt", "Resultados de MTH-A 01 — diagnóstico de familias.\nIncluye entradas, fórmulas documentadas en la guía del programa, trazabilidad y huella SHA256.\nUn blanco significa dato o cálculo no disponible. Los datos de ejemplo son sintéticos.\nNo contiene una simulación de eventos discretos ni una recomendación de proporción MTS/MTO.\n")
    return out.getvalue()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def send_bytes(self, data, kind="application/json; charset=utf-8", status=200, filename=None):
        self.send_response(status)
        self.send_header("Content-Type", kind)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        if filename:
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, data, status=200):
        self.send_bytes(json.dumps(data, ensure_ascii=False, allow_nan=False).encode("utf-8"), status=status)

    def do_GET(self):
        route = self.path.split("?")[0]
        if route == "/api/schema":
            return self.send_json({"schemas": SCHEMAS, "params": PARAMS, "token": self.server.token})
        if route == "/api/ejemplo":
            return self.send_json(load_example())
        static = {"/": ("web/index.html", "text/html; charset=utf-8"), "/app.js": ("web/app.js", "text/javascript; charset=utf-8"), "/style.css": ("web/style.css", "text/css; charset=utf-8"), "/guia": ("docs/GUIA_DATOS_Y_USO.html", "text/html; charset=utf-8")}
        if route in static:
            path, kind = static[route]
            return self.send_bytes((ROOT / path).read_bytes(), kind)
        if route.startswith("/plantilla/") and route[len("/plantilla/"):] in SCHEMAS:
            name = route[len("/plantilla/"):]
            return self.send_bytes((ROOT / "plantillas" / (name + ".csv")).read_bytes(), "text/csv; charset=utf-8", filename=name + ".csv")
        self.send_json({"error": "Ruta no disponible."}, 404)

    def do_POST(self):
        if self.headers.get("X-MTHA-Token") != self.server.token:
            return self.send_json({"error": "Recargá la página para recuperar la sesión local."}, 403)
        if self.path not in {"/api/analizar", "/api/exportar"}:
            return self.send_json({"error": "Ruta no disponible."}, 404)
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 < size <= 10 * 1024 * 1024:
                raise InputError("El proyecto está vacío o supera 10 MB.")
            payload = json.loads(self.rfile.read(size))
            result = analyze(payload)
            if self.path == "/api/analizar":
                return self.send_json(result)
            binary = export_zip(payload, result)
            folder = ROOT / "resultados"
            folder.mkdir(exist_ok=True)
            name = "MTHA_RESULTADOS_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".zip"
            (folder / name).write_bytes(binary)
            return self.send_bytes(binary, "application/zip", filename=name)
        except (InputError, ValueError, TypeError, KeyError, OverflowError) as exc:
            self.send_json({"error": str(exc)}, 400)
        except OSError:
            self.send_json({"error": "No se pudo guardar. Extraé el programa en una carpeta con permiso de escritura."}, 500)


def make_server(port=8765):
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.token = secrets.token_urlsafe(32)
    return server


def main():
    parser = argparse.ArgumentParser(description="MTH-A 01: carga y análisis por familia")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()
    try:
        server = make_server(args.port)
    except OSError as exc:
        print(f"No se pudo abrir el puerto {args.port}: {exc}. Probá: python app.py --port 8766")
        return
    url = f"http://127.0.0.1:{server.server_port}"
    print(f"MTH-A abierto en {url}\nDejá esta ventana abierta. Ctrl+C para cerrar.", flush=True)
    if not args.no_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
