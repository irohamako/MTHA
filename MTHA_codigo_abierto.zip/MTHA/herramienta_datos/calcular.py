#!/usr/bin/env python3
"""Alternativa sin interfaz: python calcular.py ejemplo/PROYECTO_EJEMPLO.json"""
import argparse
import json
from pathlib import Path
from app import export_zip
from mtha.analisis import analyze

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("proyecto")
    p.add_argument("--salida", default="resultados/RESULTADOS_CLI.zip")
    args = p.parse_args()
    data = json.loads(Path(args.proyecto).read_text(encoding="utf-8-sig"))
    result = analyze(data)
    path = Path(args.salida)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(export_zip(data, result))
    print(f"Calculadas {len(result['resultados'])} familias. Archivo: {path.resolve()}")
