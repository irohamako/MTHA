"""Regenera únicamente plantillas y ejemplos; no modifica proyectos del usuario."""
import json
from pathlib import Path
from mtha.analisis import SCHEMAS, PARAMS, csv_text

ROOT = Path(__file__).resolve().parent
SOURCE = "Ejemplo didáctico diseñado para probar el programa; sin datos industriales"


def build():
    rows = {t: [] for t in SCHEMAS}
    rows["FAMILIAS"] = [dict(zip(SCHEMAS["FAMILIAS"], r)) for r in [
        ["A", "Familia A experimental", "60x60", "mate", "m2", "UM", "precios constantes del ejemplo 2025", "sintetico", SOURCE],
        ["B", "Familia B experimental", "60x120", "pulido", "m2", "UM", "precios constantes del ejemplo 2025", "sintetico", SOURCE],
    ]]
    quantities = {"A": [10000, 11000, 10500, 12000, 11500, 11000, 12500, 13000, 12000, 11500, 12500, 14000], "B": [1000, 3000, 0, 2000, 500, 4000, 1000, 5000, 1500, 0, 3500, 2500]}
    for fid, values in quantities.items():
        for i, quantity in enumerate(values, 1):
            m = f"2025-{i:02d}"
            rows["DEMANDA"].append(dict(zip(SCHEMAS["DEMANDA"], [fid, m, quantity, quantity, quantity // 100, "sintetico", SOURCE])))
            # Los saldos de meses consecutivos enlazan; no son inventarios medidos.
            initial = (5000 if fid == "A" else 2000) + (i - 1) * (50 if fid == "A" else 20)
            final = initial + (50 if fid == "A" else 20)
            rows["INVENTARIO"].append(dict(zip(SCHEMAS["INVENTARIO"], [fid, m, initial, final, "", "sintetico", SOURCE])))
    params = {
        "A": {"costo_unitario": 20, "tasa_mantenimiento_anual": .30, "capacidad_efectiva_m2_h": 60, "horas_asignadas_mes": 240, "lead_time_mto_sin_cola_dias": 7, "lead_time_cliente_dias": 10, "lote_minimo_m2": 200, "setup_h": 2},
        "B": {"costo_unitario": 30, "tasa_mantenimiento_anual": .35, "capacidad_efectiva_m2_h": 40, "horas_asignadas_mes": 100, "lead_time_mto_sin_cola_dias": 12, "lead_time_cliente_dias": 8, "lote_minimo_m2": 100, "setup_h": 3},
    }
    for fid, entries in params.items():
        for key, value in entries.items():
            row = dict.fromkeys(SCHEMAS["PARAMETROS_MTHA"], "")
            row.update(familia_id=fid, parametro=key, valor=value, unidad=PARAMS[key][0], modo="directo", tipo_dato="sintetico", fuente=SOURCE, justificacion="Parámetro experimental para demostrar el cálculo; no estima a ILVA.", fecha_fuente="2026-09-13")
            if fid == "A" and key == "costo_unitario":
                row.update(valor="", modo="lineal", normalizado=50.5, min_real=10, max_real=30, justificacion="Rango didáctico 10 a 30 UM/m2, elegido solo para probar la reversibilidad; no es un rango industrial validado.")
            rows["PARAMETROS_MTHA"].append(row)
    for table, fields in SCHEMAS.items():
        (ROOT / "plantillas").mkdir(exist_ok=True)
        (ROOT / "ejemplo").mkdir(exist_ok=True)
        (ROOT / "plantillas" / (table + ".csv")).write_text(csv_text([], fields), encoding="utf-8")
        (ROOT / "ejemplo" / (table + ".csv")).write_text(csv_text(rows[table], fields), encoding="utf-8")
    project = {"version_proyecto": 1, "inicio": "2025-01", "fin": "2025-12", "tables": {t: csv_text(rows[t], SCHEMAS[t]) for t in SCHEMAS}}
    (ROOT / "ejemplo" / "PROYECTO_EJEMPLO.json").write_text(json.dumps(project, ensure_ascii=False, indent=2), encoding="utf-8")
    catalogue = []
    for key, (unit, _, _, source) in PARAMS.items():
        row = dict.fromkeys(SCHEMAS["PARAMETROS_MTHA"], "")
        row.update(familia_id="REEMPLAZAR_POR_ID", parametro=key, unidad=unit, modo="directo", justificacion=source)
        catalogue.append(row)
    (ROOT / "plantillas" / "CATALOGO_PARAMETROS.csv").write_text(csv_text(catalogue, SCHEMAS["PARAMETROS_MTHA"]), encoding="utf-8")


if __name__ == "__main__":
    build()
