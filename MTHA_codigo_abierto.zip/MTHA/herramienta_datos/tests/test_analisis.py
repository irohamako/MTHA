import copy
import io
import json
import math
import threading
import unittest
import urllib.error
import urllib.request
import zipfile

from app import export_zip, make_server
from mtha.analisis import InputError, PARAMS, SCHEMAS, analyze, csv_text, normalized_value, read_csv, resolved_parameter


def fixture():
    rows = {
        "FAMILIAS": [dict(zip(SCHEMAS["FAMILIAS"], ["001", "Ensayo", "60x60", "mate", "m2", "UM", "2025 constantes", "sintetico", "prueba analítica"]))],
        "DEMANDA": [dict(zip(SCHEMAS["DEMANDA"], ["001", f"2025-{i:02d}", d, d, d // 10, "sintetico", "prueba analítica"])) for i, d in enumerate([100, 200, 300], 1)],
        "INVENTARIO": [dict(zip(SCHEMAS["INVENTARIO"], ["001", f"2025-{i:02d}", "", "", 10, "sintetico", "prueba analítica"])) for i in range(1, 4)],
        "PARAMETROS_MTHA": [],
    }
    values = {"costo_unitario": 2, "tasa_mantenimiento_anual": .5, "capacidad_efectiva_m2_h": 10, "horas_asignadas_mes": 10, "lead_time_mto_sin_cola_dias": 3, "lead_time_cliente_dias": 2}
    for k, v in values.items():
        row = dict.fromkeys(SCHEMAS["PARAMETROS_MTHA"], "")
        row.update(familia_id="001", parametro=k, valor=v, unidad=PARAMS[k][0], modo="directo", tipo_dato="sintetico", fuente="prueba analítica", justificacion="caso verificable")
        rows["PARAMETROS_MTHA"].append(row)
    return {"inicio": "2025-01", "fin": "2025-03", "tables": {t: csv_text(r, SCHEMAS[t]) for t, r in rows.items()}}


def edit(p, table, fn):
    rows = read_csv(p["tables"][table], table)
    fn(rows)
    p["tables"][table] = csv_text(rows, SCHEMAS[table])


class TestAnalysis(unittest.TestCase):
    def test_hand_calculation(self):
        r = analyze(fixture())["resultados"][0]
        expected = {"familia_id": "001", "demanda_media_mensual_m2": 200, "desviacion_mensual_m2": 100, "cv_mensual": .5, "stock_promedio_m2": 10, "rotacion_periodo": 60, "capital_promedio": 20, "costo_mantenimiento_anual_equivalente": 10, "carga_demanda_sobre_capacidad": 2, "holgura_mto_sin_cola_dias": -1, "pedido_promedio_m2": 10}
        for k, v in expected.items():
            self.assertEqual(r[k], v, k)
        self.assertAlmostEqual(r["cobertura_stock_promedio_dias"], 1.5)

    def test_missing_is_not_zero(self):
        p = fixture()
        edit(p, "DEMANDA", lambda r: r.pop(1))
        r = analyze(p)["resultados"][0]
        self.assertIsNone(r["demanda_media_mensual_m2"])
        self.assertEqual(r["meses_con_demanda"], 2)
        self.assertIsNone(r["participacion_volumen"])

    def test_zero_demand_and_one_observation(self):
        p = fixture()
        edit(p, "DEMANDA", lambda rows: [r.update(demanda_m2="0", despachado_m2="0", numero_pedidos="0") for r in rows])
        r = analyze(p)["resultados"][0]
        self.assertEqual(r["demanda_media_mensual_m2"], 0)
        self.assertIsNone(r["cv_mensual"])
        self.assertIsNone(r["cobertura_stock_promedio_dias"])
        self.assertEqual(r["rotacion_periodo"], 0)
        p["fin"] = "2025-01"
        self.assertIsNone(analyze(p)["resultados"][0]["desviacion_mensual_m2"])

    def test_stock_average_weighted_and_single_snapshot(self):
        p = fixture()
        edit(p, "INVENTARIO", lambda rows: [r.update(stock_inicio_m2=str(i * 10), stock_fin_m2=str((i + 1) * 10), stock_promedio_m2="") for i, r in enumerate(rows)])
        r = analyze(p)["resultados"][0]
        self.assertAlmostEqual(r["stock_promedio_m2"], (5 * 31 + 15 * 28 + 25 * 31) / 90)
        self.assertEqual(r["stock_promedio_metodo"], "incluye_aproximacion_extremos")
        edit(p, "INVENTARIO", lambda rows: rows[0].update(stock_inicio_m2=""))
        self.assertIsNone(analyze(p)["resultados"][0]["stock_promedio_m2"])

    def test_rotation_requires_shipments_and_money_requires_basis(self):
        p = fixture()
        edit(p, "DEMANDA", lambda rows: rows[0].update(despachado_m2=""))
        edit(p, "FAMILIAS", lambda rows: rows[0].update(base_precios=""))
        r = analyze(p)["resultados"][0]
        self.assertIsNone(r["rotacion_periodo"])
        self.assertIsNone(r["capital_promedio"])
        self.assertEqual(r["demanda_total_m2"], 600)

    def test_reversible_linear_and_log(self):
        base = read_csv(fixture()["tables"]["PARAMETROS_MTHA"], "PARAMETROS_MTHA")[0]
        for mode in ["lineal", "log"]:
            for x in [10, 20, 40, 100]:
                row = {**base, "valor": "", "modo": mode, "min_real": "10", "max_real": "100", "normalizado": str(normalized_value(x, 10, 100, mode))}
                self.assertAlmostEqual(resolved_parameter(row), x)
        with self.assertRaises(InputError):
            normalized_value(200, 10, 100)
        with self.assertRaises(InputError):
            resolved_parameter({**base, "modo": "lineal", "normalizado": "50", "min_real": "10", "max_real": "100"})

    def test_bad_inputs_duplicates_and_units(self):
        for val in ["NaN", "inf", "-1", "1.000,5", "texto"]:
            p = fixture()
            edit(p, "DEMANDA", lambda rows: rows[0].update(demanda_m2=val))
            with self.assertRaises(InputError, msg=val):
                analyze(p)
        p = fixture()
        edit(p, "DEMANDA", lambda rows: rows.append(rows[0].copy()))
        with self.assertRaises(InputError):
            analyze(p)
        p = fixture()
        edit(p, "FAMILIAS", lambda rows: rows[0].update(unidad="kg"))
        with self.assertRaises(InputError):
            analyze(p)

    def test_csv_decimal_comma_tsv_and_provenance(self):
        p = fixture()
        edit(p, "DEMANDA", lambda rows: rows[0].update(demanda_m2="100,5"))
        r = analyze(p)["resultados"][0]
        self.assertAlmostEqual(r["demanda_total_m2"], 600.5)
        p["tables"]["DEMANDA"] = p["tables"]["DEMANDA"].replace(";", "\t")
        self.assertAlmostEqual(analyze(p)["resultados"][0]["demanda_total_m2"], 600.5)
        edit(p, "DEMANDA", lambda rows: rows[0].update(fuente=""))
        with self.assertRaises(InputError):
            analyze(p)

    def test_zero_capacity_and_real_replacement_snapshot(self):
        p = fixture()
        before = analyze(p)
        archive = export_zip(p, before)
        edit(p, "PARAMETROS_MTHA", lambda rows: [r.update(valor="0", tipo_dato="real", fuente="registro verificado de prueba") for r in rows if r["parametro"] == "horas_asignadas_mes"])
        after = analyze(p)
        self.assertIsNone(after["resultados"][0]["carga_demanda_sobre_capacidad"])
        self.assertNotEqual(before["sha256_entradas"], after["sha256_entradas"])
        with zipfile.ZipFile(io.BytesIO(archive)) as z:
            self.assertEqual(json.loads(z.read("RESULTADOS.json"))["resultados"][0]["carga_demanda_sobre_capacidad"], 2)

    def test_http_analysis_and_export(self):
        server = make_server(0)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{server.server_port}"
        try:
            with urllib.request.urlopen(base + "/api/schema") as r:
                schema = json.load(r)
            for path in ["/", "/app.js", "/style.css", "/guia", "/plantilla/FAMILIAS", "/api/ejemplo"]:
                with urllib.request.urlopen(base + path) as r:
                    self.assertEqual(r.status, 200)
            body = json.dumps(fixture()).encode()
            req = urllib.request.Request(base + "/api/analizar", data=body, headers={"X-MTHA-Token": schema["token"]})
            with urllib.request.urlopen(req) as r:
                self.assertEqual(json.load(r)["resultados"][0]["cv_mensual"], .5)
            req = urllib.request.Request(base + "/api/exportar", data=body, headers={"X-MTHA-Token": schema["token"]})
            with urllib.request.urlopen(req) as r:
                with zipfile.ZipFile(io.BytesIO(r.read())) as z:
                    self.assertIn("RESULTADOS_FAMILIAS.csv", z.namelist())
                    self.assertEqual(json.loads(z.read("PROYECTO.json")), fixture())
            with self.assertRaises(urllib.error.HTTPError) as cm:
                urllib.request.urlopen(urllib.request.Request(base + "/api/analizar", data=body))
            self.assertEqual(cm.exception.code, 403)
        finally:
            server.shutdown()
            server.server_close()


if __name__ == "__main__":
    unittest.main()
