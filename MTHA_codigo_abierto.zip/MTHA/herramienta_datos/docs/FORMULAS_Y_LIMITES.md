# Fórmulas y límites de la primera etapa

Todos los indicadores se agrupan por familia y por el período común elegido. Son cálculos deterministas sobre las entradas; no son resultados simulados. No se imputa información faltante.

| Salida | Fórmula y condición |
|---|---|
| Demanda total | Suma de demanda mensual de todo el período. Si falta algún mes, queda vacía. |
| Media mensual | Total / cantidad de meses. Los meses con cero confirmado cuentan. |
| Desviación mensual | Desviación muestral s = sqrt(sum((x-media)^2)/(n-1)); requiere n ≥ 2 y serie completa. |
| CV mensual | s / media. No definido si media = 0. Compara dispersión relativa; la agregación por familia puede ocultar intermitencia de SKU. |
| Demanda diaria media | Demanda total / días calendario exactos del período. No calcula ni infiere desviación diaria. |
| Participación en volumen | Demanda de familia / demanda de todas las familias cargadas. Requiere todas las series completas; no es un ABC económico. |
| Pedido promedio | Demanda total / cantidad total de pedidos del mismo período. No definido con cero pedidos. |
| Stock promedio mensual | Valor aportado de promedio temporal del mes. Si no existe y hay dos extremos: (inicio + fin)/2, marcado como aproximación. Un único saldo no habilita promedio. |
| Stock promedio del período | Promedios mensuales ponderados por días calendario de cada mes; requiere todos los meses. Supone los stocks expresados en m² de producto terminado de la misma familia. |
| Cobertura del stock promedio | Stock promedio / demanda diaria media. Es cobertura equivalente histórica, no disponibilidad garantizada ni antigüedad. |
| Rotación del período | Despachos totales del período / stock promedio. No usa pedidos solicitados como sustituto de despachos. No se anualiza. No definida con stock promedio cero. |
| Capital promedio | Stock promedio × costo unitario. Es valor de producto terminado, excluye WIP/materias primas. Requiere moneda y base de precios. Costo unitario constante representativo de la familia. |
| Costo de mantenimiento anual equivalente | Capital promedio × tasa anual total de mantenimiento. Es una extrapolación anual de ese stock medio, no costo histórico efectivamente pagado ni flujo de caja. No añade componentes de costo por separado. |
| Capacidad asignada mensual | Capacidad efectiva de salida buena (m²/h programada) × horas asignadas a la familia por mes. No vuelve a restar disponibilidad, scrap o setup si ya están incluidos en la tasa efectiva. |
| Carga demanda/capacidad | Demanda media mensual / capacidad mensual asignada. Es carga requerida, no utilización observada. No comprueba competencia entre familias por recursos compartidos. |
| Holgura MTO sin cola | Plazo cliente − tiempo total MTO sin cola (administración + fabricación + despacho/transporte). Valor negativo descarta cumplir ese plazo con las hipótesis cargadas; valor positivo no garantiza cumplimiento. |

Los meses no informados no se convierten en cero. Los campos numéricos vacíos quedan como `null` en JSON y blancos en CSV. En la interfaz se muestran como «—». Series fuera del período generan aviso y se excluyen de los indicadores; se conserva el archivo original en la exportación.

Los costos de distintas monedas o fechas base se muestran por separado; el programa no los suma ni ajusta inflación automáticamente. Para comparar familias, usar una base homogénea y el costo unitario apropiado de cada familia. Ventas facturadas, demanda solicitada y despachos son conceptos distintos. Los despachos pueden superar a pedidos del mes por cancelación de pendientes anteriores; por eso no se fuerza despachos ≤ demanda.

## Normalización reversible

Todas las variables físicas siguen calculándose en sus unidades. El índice 1–100 es solo una forma de parametrizar, no un puntaje de conveniencia.

- Modo `directo`: utiliza `valor`. Es el modo recomendado para empezar y para datos reales.
- Modo `lineal`: x = a + (z−1)/99 × (b−a). Inversa z = 1 + 99 × (x−a)/(b−a). Apropiado cuando incrementos iguales en z deben representar incrementos físicos iguales en un rango documentado.
- Modo `log`: x = exp(log(a)+(z−1)/99 × log(b/a)). Inversa z = 1 + 99 × log(x/a)/log(b/a). Requiere a > 0; útil cuando cambios proporcionales y órdenes de magnitud tienen sentido.

Se admiten decimales del índice: redondearlo a un entero pierde precisión. Estas transformaciones no generan una distribución aleatoria. No se usan para nombres, familias, estrategias ni fechas. En modos normalizados, `valor` debe estar vacío para no tener dos entradas activas. El rango requiere fuente y justificación; no se deriva de una escala industrial universal. El modo directo acepta valores físicos válidos aunque superen un antiguo rango experimental: se registra el dato real sin recortarlo. Antes de reemplazar, guardar el proyecto y luego una versión nueva con fecha, tipo y fuente actualizados.

## Qué se solicita en la etapa siguiente

Pedidos individuales y entregas permiten definir cohortes de OTIF y fill rate; un total mensual no alcanza. Para tiempos y recursos hacen falta rutas, capacidades por etapa, calendarios, lotes, setups, scrap y reglas de prioridad. El tiempo de residencia de horno no equivale a capacidad: un horno continuo puede contener varias piezas simultáneamente.

No hay ranking MTS/MTO en esta etapa. La holgura de plazo es un filtro necesario parcial, no una regla óptima. No se fuerza un CODP físico.

## Fuentes metodológicas y técnicas

- NIST, Coefficient of Variation: https://www.itl.nist.gov/div898/software/dataplot/refman2/auxillar/coefvari.htm — definición s/media.
- Python, statistics: https://docs.python.org/3.12/library/statistics.html — media y desviación muestral implementadas con biblioteca estándar.
- Python, http.server: https://docs.python.org/3.12/library/http.server.html — servidor utilizado exclusivamente en localhost.
- Las identidades de stock, cobertura, capital y carga están definidas explícitamente arriba como convenciones de este prototipo. Los ejemplos de entrada son sintéticos y no se atribuyen a esas fuentes ni a ILVA.

Fuentes consultadas el 13 de septiembre de 2026. Versión del programa 1.0.0.
