# MTH-A · Make-To-Hybrid Argentina

Herramienta de código abierto para **segmentar, parametrizar, simular y evaluar económicamente** políticas de producción híbridas entre producción para stock (*Make-to-Stock*, MTS) y producción bajo pedido (*Make-to-Order*, MTO).

Fue desarrollada como parte del Proyecto Final de Ingeniería Industrial *«Diseño de un Sistema de Adaptación Competitiva para Industrias Argentinas ante Cambios Macroeconómicos Acelerados»* (Universidad del Salvador, Facultad de Ingeniería, 2026), a partir del caso reconstruido de una familia de porcelanato de 60 × 60 cm.

> Los resultados que produce la herramienta son **experimentales**: dependen de los parámetros cargados. No son mediciones de ninguna empresa real ni una recomendación automática de proporción MTS/MTO.

## Qué incluye

| Carpeta | Componente | Para qué sirve |
|---|---|---|
| `herramienta_datos/` | Herramienta de datos e indicadores (v1.0.0, 13/9/2026) | Cargar familias, demanda, inventario y parámetros; calcular CV, cobertura, rotación, capital, carga y holgura MTO. Interfaz web local. Solo biblioteca estándar de Python. |
| `sistema_web/` | Sistema de simulación económica (28/9/2026) | Ejecutar la comparación entre MTS100 y una política híbrida (H70, H50, H30) con réplicas pareadas y obtener VAN incremental, ROI, inventario, servicio y costos. |
| `aplicacion_escritorio/` | Aplicación de escritorio unificada (v1.0.0, 28/9/2026) | Integrar proyecto, demanda, inventario y capacidad, simulación, recorrido de eventos y economía en una sola aplicación local (Tkinter). |
| `docs/` | Documentación | Arquitectura, reproducción de resultados y adaptación a otros casos. |

## Requisitos

- Python 3.11 o posterior, de 64 bits (probado con 3.12).
- `herramienta_datos/`: no requiere paquetes externos.
- `sistema_web/` y `aplicacion_escritorio/`: `numpy`, `scipy` y `simpy` (versiones fijadas en cada `requirements.txt`).

```bash
pip install -r aplicacion_escritorio/requirements.txt
```

## Uso rápido

```bash
# Herramienta de datos (abre http://127.0.0.1:8765)
cd herramienta_datos && python app.py

# Sistema de simulación económica en el navegador
cd sistema_web && python sistema.py

# Aplicación de escritorio
cd aplicacion_escritorio && python app.py
```

En Windows también pueden usarse los iniciadores `.bat` de cada carpeta. Cada componente incluye su propio `LEER_PRIMERO.txt` o `LEEME.md` con instrucciones detalladas.

## Reproducir los resultados de la tesis

La configuración del caso está en `motor/configuracion_operativa.json` y `motor/parametros_economicos_previos.json`. Con los valores originales:

- Política H70 frente a MTS100, semilla `20260925`, 100 réplicas pareadas.
- Resultado esperado del escenario central: VAN incremental medio de 2.017.082 ARS (IC 95 %: 1.516.322 – 2.517.842), inventario terminado medio de 16.181,98 m² en H70 frente a 21.837,81 m² en MTS100 y OTIF de 99,55 % frente a 99,77 %.
- La primera réplica produce un VAN incremental de 1.749.094,62 ARS y un inventario medio de H70 de 16.150,92 m².

Ver `docs/REPRODUCIR_RESULTADOS.md`.

## Verificación

- `herramienta_datos/tests/`: 10 pruebas unitarias (`python -m unittest discover -s tests`).
- `aplicacion_escritorio/pruebas/comprobar.py`: almacenamiento, integración del motor, coincidencia con la ejecución original y conciliación de caja.
- Los archivos `VERIFICACION.txt` / `VERIFICACION.json` documentan las comprobaciones realizadas en cada versión.

## Adaptar la herramienta a otra industria

El modelo no está atado al porcelanato: la familia, los grupos, la demanda, el lote, el ritmo neto, las ventanas de capacidad, los plazos de los clientes, el abastecimiento y los costos son parámetros. Ver `docs/ARQUITECTURA.md`, sección «Adaptación».

## Limitaciones conocidas

- Un recurso productivo agregado; las otras familias se representan como tiempo no disponible.
- La asignación de grupos a MTS o MTO es fija durante cada corrida; la adaptación se realiza reevaluando escenarios.
- Los materiales se reponen como conjuntos completos de receta.
- Los datos de ejemplo de `herramienta_datos/ejemplo/` (familias A y B) son **sintéticos** y solo sirven para probar el programa.

## Licencia

Distribuido bajo la licencia MIT. Ver `LICENSE`.

## Cómo citar

Ver `CITATION.cff`. Formato sugerido:

ALMAR, Agustín Nicolás. *MTH-A: herramienta de simulación y evaluación de políticas híbridas MTS/MTO* [software]. Versión 1.0.0. Buenos Aires, 2026.

## Autor

Agustín Nicolás Almar · ORCID [0009-0009-4792-1679](https://orcid.org/0009-0009-4792-1679)
Director del proyecto: Ing. Juan José Grassi · ORCID [0009-0004-8717-6689](https://orcid.org/0009-0004-8717-6689)
