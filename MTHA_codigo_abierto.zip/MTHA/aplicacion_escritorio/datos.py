"""Usuarios locales, proyectos y parámetros compartidos de MTH-A."""
from pathlib import Path
import sqlite3,json,hashlib,hmac,secrets,os,math,calendar,copy
from datetime import datetime
ROOT=Path(__file__).resolve().parent
DATA=Path(os.environ.get('MTHA_DATA_DIR') or (Path(os.environ.get('LOCALAPPDATA') or Path.home())/'MTHA'))

def months(start,n):
    d=datetime.strptime(start,'%Y-%m');v=d.year*12+d.month-1
    return [f'{(v+i)//12:04d}-{(v+i)%12+1:02d}' for i in range(n)]

def new_project():
    c=json.loads((ROOT/'motor/configuracion_operativa.json').read_text(encoding='utf-8'))
    c.pop('procedencia',None)
    return {'nombre':'Mi primera operación','familia':'Porcelanato 60 × 60','inicio':'2025-03','meses':10,'moneda':'ARS','base':'Precios constantes · marzo 2025',
      'replicas':3,'semilla':20260925,'grupos_mts':['G1','G2','G3'],'operacion':c,
      'mercado':{'mensual':4200000,'zona':35,'cuota':7,'familia':42.8571428571},
      'economia':{'real_rate':.10,'residual_fraction':1.,'implementation_services':1309060.,'implementation_assets':85840.,'contingency_fraction':.15,'support_monthly':32190.,'holding_monthly':0.,'dso_days':45,'dpo_days':30,'price_factor':1.,'material_factor':1.,'energy_factor':1.},
      'precios':{'price':13000.,'fx':1073.,'ret':.015,'iibb':.015,'municipal':.005,'comm':.005,'freight':.6,'handle':.08,'reverse':1.4,'bank':.006},
      'costos':{'matlot_usd':3414.8,'pack_usd':.55,'elec_m2':870.,'gas_mj':110.,'gas_usd':7.5,'maintenance_usd_h':12.0833333333333,'water_lot':4000.,'labor_factory':44397725.82602322,'admin':219770.76023741934,'fixed_energy':483870.96774193546,'depreciation':5191935.483870967,'store':500000.,'idle_fraction':.1,'startup_mj':30000.,'vat':.21,'vat_energy':.27},'notas':'Valores de demostración. Sustituir por los datos de la empresa antes de decidir.'}

def number(v,name,lo=0,hi=1e12,integer=False):
    try:x=float(str(v).strip().replace(',','.'))
    except ValueError:raise ValueError(f'{name}: ingresá un número sin separador de miles.')
    if not math.isfinite(x) or not lo<=x<=hi:raise ValueError(f'{name}: debe estar entre {lo:g} y {hi:g}.')
    if integer and x!=int(x):raise ValueError(f'{name}: debe ser entero.')
    return int(x) if integer else x

def prepare(p):
    p=copy.deepcopy(p);n=number(p['meses'],'Meses',1,24,True);ms=months(p['inicio'],n)
    p['meses']=n
    c=p['operacion'];c['inicio']=ms[0]+'-01';c['fin']=months(p['inicio'],n+1)[-1]+'-01';c['seguimiento_dias']=30
    if len(c['demanda_mensual'])!=n:raise ValueError('Guardá el horizonte y completá todos los meses de demanda.')
    for i,m in enumerate(c['demanda_mensual']):m['mes']=ms[i];m['m2']=number(m['m2'],'Demanda mensual',0,1e7)
    pr=c['parametros'];pr['monthly_demand']=c['demanda_mensual'][0]['m2'];pr['days']=calendar.monthrange(*map(int,ms[0].split('-')))[1]
    for k in ('net_rate','lot','order_mean','planning_lead_days'):pr[k]=number(pr[k],k,.001,1e7)
    for k in ('order_sd','quality_hours','transport_hours','initial_fg','initial_wip','initial_backlog'):pr[k]=number(pr[k],k,0,1e8)
    if pr['order_mean']<1:raise ValueError('El pedido medio debe ser al menos 1 m².')
    if sum(m['m2'] for m in c['demanda_mensual'])/pr['order_mean']>100000:raise ValueError('Reducí la demanda o aumentá el pedido medio: máximo 100.000 pedidos esperados por réplica.')
    if abs(sum(g['share'] for g in c['grupos'])-1)>1e-8:raise ValueError('Los porcentajes de los grupos deben sumar 100 %.')
    for g in c['grupos']:
        number(g['share'],'Participación',0,1);number(g['deadline_days'],'Plazo del grupo',0,90)
        for key in ('initial_fg','initial_wip','initial_backlog'):g[key]=pr[key]*g['share']
    pr['forecast_smoothing']=number(pr['forecast_smoothing'],'Suavizado',0,1)
    p['replicas']=number(p['replicas'],'Réplicas',1,100,True);p['semilla']=number(p['semilla'],'Semilla',0,4294967295,True)
    if not set(p['grupos_mts'])<=set(g['id'] for g in c['grupos']):raise ValueError('Grupo desconocido.')
    for k,v in p['economia'].items():p['economia'][k]=number(v,k,0,1e10)
    for k in ('real_rate','residual_fraction','contingency_fraction'):number(p['economia'][k],k,0,1)
    for k in ('dso_days','dpo_days'):number(p['economia'][k],k,0,60)
    for k,v in p['precios'].items():p['precios'][k]=number(v,'Precio / tasa',0,1e10)
    if p['precios']['fx']<=0 or p['precios']['price']<=0:raise ValueError('Precio y tipo de cambio deben ser positivos.')
    for k in ('ret','iibb','municipal','comm','bank'):number(p['precios'][k],k,0,1)
    for k,v in p['costos'].items():p['costos'][k]=number(v,'Costo',0,1e12)
    for k in ('idle_fraction','vat','vat_energy'):number(p['costos'][k],k,0,1)
    width=c['ventanas'][0][1];number(width,'Horas por ventana',.1,192)
    c['ventanas']=[[a,a+width] for a in (0,240,480)]
    for v in c['materiales'].values():
        if isinstance(v,(int,float)) and not isinstance(v,bool):number(v,'Materiales',0,1e9)
    if c['materiales']['objetivo_dias']<c['materiales']['punto_pedido_dias']:raise ValueError('El objetivo de materia prima no puede ser menor al punto de pedido.')
    return p

class Store:
    def __init__(self,path=None):
        self.path=Path(path) if path else DATA/'mtha.sqlite';self.path.parent.mkdir(parents=True,exist_ok=True)
        with self.connect() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,name TEXT,company TEXT,salt TEXT,hash TEXT);
            CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY,user_id INTEGER,name TEXT,data TEXT,updated TEXT);
            CREATE TABLE IF NOT EXISTS runs(id INTEGER PRIMARY KEY,user_id INTEGER,project_id INTEGER,name TEXT,folder TEXT,created TEXT,kind TEXT);''')
    def connect(self):
        db=sqlite3.connect(self.path);db.row_factory=sqlite3.Row;return db
    def register(self,name,company,user,password):
        if not name.strip() or not company.strip() or not user.strip():raise ValueError('Completá nombre, empresa y usuario.')
        if any(len(v)>80 for v in (name,company,user)):raise ValueError('Nombre, empresa y usuario admiten hasta 80 caracteres.')
        if len(password)<8:raise ValueError('La contraseña debe tener al menos 8 caracteres.')
        salt=secrets.token_hex(16);digest=hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(salt),300000).hex()
        try:
            with self.connect() as db:db.execute('INSERT INTO users(username,name,company,salt,hash) VALUES(?,?,?,?,?)',(user.strip().casefold(),name.strip(),company.strip(),salt,digest))
        except sqlite3.IntegrityError:raise ValueError('Ese nombre de usuario ya existe.')
    def login(self,user,password):
        with self.connect() as db:r=db.execute('SELECT * FROM users WHERE username=?',(user.strip().casefold(),)).fetchone()
        if not r:raise ValueError('Usuario o contraseña incorrectos.')
        digest=hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(r['salt']),300000).hex()
        if not hmac.compare_digest(digest,r['hash']):raise ValueError('Usuario o contraseña incorrectos.')
        return {k:r[k] for k in ('id','name','company','username')}
    def save(self,uid,p,pid=None):
        p=prepare(p);now=datetime.now().isoformat(timespec='seconds')
        with self.connect() as db:
            if pid:
                cur=db.execute('UPDATE projects SET name=?,data=?,updated=? WHERE id=? AND user_id=?',(p['nombre'],json.dumps(p,ensure_ascii=False),now,pid,uid))
                if cur.rowcount!=1:raise ValueError('Proyecto no disponible para este usuario.')
            else:pid=db.execute('INSERT INTO projects(user_id,name,data,updated) VALUES(?,?,?,?)',(uid,p['nombre'],json.dumps(p,ensure_ascii=False),now)).lastrowid
        return pid
    def projects(self,uid):
        with self.connect() as db:return [dict(x) for x in db.execute('SELECT id,name,updated FROM projects WHERE user_id=? ORDER BY updated DESC',(uid,))]
    def load(self,uid,pid):
        with self.connect() as db:r=db.execute('SELECT data FROM projects WHERE id=? AND user_id=?',(pid,uid)).fetchone()
        if not r:raise ValueError('Proyecto no disponible.')
        return json.loads(r[0])
    def add_run(self,uid,pid,name,folder,kind):
        with self.connect() as db:db.execute('INSERT INTO runs(user_id,project_id,name,folder,created,kind) VALUES(?,?,?,?,?,?)',(uid,pid,name,str(folder),datetime.now().isoformat(timespec='seconds'),kind))
    def runs(self,uid):
        with self.connect() as db:return [dict(r) for r in db.execute('SELECT * FROM runs WHERE user_id=? ORDER BY id DESC',(uid,))]
