"""Comprobaciones del almacenamiento y de la integración del motor."""
import sys,tempfile,json,subprocess,copy,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from datos import Store,new_project,prepare

def execute(p,kind,folder):
    folder.mkdir();(folder/'proyecto.json').write_text(json.dumps(p),encoding='utf-8')
    proc=subprocess.run([sys.executable,str(ROOT/'tareas.py'),str(folder),kind],capture_output=True,text=True)
    assert proc.returncode==0,(proc.stderr,(folder/'diagnostico.txt').read_text() if (folder/'diagnostico.txt').exists() else '')
    return json.loads((folder/'resumen.json').read_text(encoding='utf-8'))

with tempfile.TemporaryDirectory() as td:
    root=Path(td);s=Store(root/'users.sqlite');s.register('Persona A','Empresa A','uno','claveprueba');s.register('Persona B','Empresa B','dos','claveprueba')
    a=s.login('uno','claveprueba');b=s.login('dos','claveprueba');p=prepare(new_project());pid=s.save(a['id'],p)
    assert s.projects(b['id'])==[]
    try:s.load(b['id'],pid);raise AssertionError('Acceso cruzado')
    except ValueError:pass
    try:s.login('uno','incorrecta');raise AssertionError('Contraseña inválida aceptada')
    except ValueError:pass
    with s.connect() as db:assert db.execute('SELECT hash FROM users LIMIT 1').fetchone()[0]!='claveprueba'
    bad=copy.deepcopy(p);bad['operacion']['grupos'][0]['share']=.5
    try:prepare(bad);raise AssertionError('Porcentajes inválidos')
    except ValueError:pass
    p['replicas']=1;r=execute(p,'comparacion',root/'base')
    assert abs(r['van']['media']-1749094.6184198856)<.01
    assert abs(r['medias']['H70']['fg_promedio_m2']-16150.917080859934)<1e-6
    assert r['error_balance']<.02
    q=copy.deepcopy(p);q['economia']['implementation_services']+=100/(1+q['economia']['contingency_fraction'])
    rr=execute(q,'comparacion',root/'inversion');assert abs(rr['van']['media']-(r['van']['media']-100))<.01
    z=copy.deepcopy(p);z['meses']=1;z['inicio']='2026-02';z['operacion']['demanda_mensual']=[{'mes':'2026-02','m2':0}]
    for k in ('initial_fg','initial_wip','initial_backlog'):z['operacion']['parametros'][k]=0
    rz=execute(z,'comparacion',root/'cero');assert rz['medias']['H70']['otif_pct'] is None
    assert rz['medias']['H70']['fg_promedio_m2']==0
    d=execute(p,'demanda',root/'demanda');assert len(d['mensual'])==10
print('OK: usuarios aislados, contraseñas, validación, referencia numérica, inversión incremental, horizonte variable, demanda cero y generador integrado.')
