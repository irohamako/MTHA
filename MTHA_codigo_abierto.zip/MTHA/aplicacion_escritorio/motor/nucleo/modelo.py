"""Simulación MTH-A por eventos discretos, horas calendario y m² netos.

Un recurso agregado; un lote debe caber completo en su ventana.
SimPy administra el reloj y los eventos. El planificador se ejecuta después
de procesar todos los hechos de una misma hora. No ve pedidos futuros.
"""
from __future__ import annotations
from collections import defaultdict
from datetime import datetime
from statistics import NormalDist
import copy, math
import numpy as np
import simpy
from demanda import horas

VERSION='1.0.0'
EPS=1e-7

def calendario(c, fin):
    fecha=datetime.fromisoformat(c['inicio']); ventanas=[]; meses=[]
    while horas(fecha.isoformat(),c['inicio']) < fin:
        siguiente=datetime(fecha.year+(fecha.month==12),fecha.month%12+1,1)
        a=horas(fecha.isoformat(),c['inicio']); b=horas(siguiente.isoformat(),c['inicio'])
        meses.append((a,b,fecha.strftime('%Y-%m')))
        for x,y in c['ventanas']:
            if y>b-a:raise ValueError('Ventana fuera del mes')
            ventanas.append((a+x,a+y))
        fecha=siguiente
    return ventanas,meses

def validar(c, pedidos, mts):
    p=c['parametros']; ids=[g['id'] for g in c['grupos']]
    if len(ids)!=len(set(ids)) or not set(mts)<=set(ids):raise ValueError('Grupos inválidos')
    for k in ('net_rate','lot','order_mean','days','planning_lead_days'):
        if not math.isfinite(p[k]) or p[k]<=0:raise ValueError('Parámetro positivo requerido: '+k)
    for k in ('monthly_demand','order_sd','quality_hours','transport_hours','unit_cost'):
        if not math.isfinite(p[k]) or p[k]<0:raise ValueError('Parámetro no negativo requerido: '+k)
    if p['review_days']!=1:raise ValueError('Esta versión utiliza revisión diaria')
    if not 0<=p['forecast_smoothing']<=1 or not .5<p['cycle_probability']<1:raise ValueError('Probabilidad/suavizado inválido')
    if not 0<p['wip_remaining_fraction']<=1:raise ValueError('Fracción remanente de WIP inválida')
    if abs(sum(g['share'] for g in c['grupos'])-1)>EPS:raise ValueError('Las participaciones deben sumar 1')
    for g in c['grupos']:
        if any(not math.isfinite(g[k]) or g[k]<0 for k in ('share','initial_fg','initial_wip','initial_backlog','deadline_days')):raise ValueError('Grupo inválido')
    anterior=0
    for a,b in c['ventanas']:
        if not math.isfinite(a+b) or a<anterior or b<=a:raise ValueError('Ventanas superpuestas o inválidas')
        anterior=b
    if c['seguimiento_dias']<0 or horas(c['fin'],c['inicio'])<=0:raise ValueError('Horizonte inválido')
    m=c['materiales']
    for k in ('cobertura_inicial_dias','plazo_dias','punto_pedido_dias','objetivo_dias','cuerpo_kg_lote','esmalte_kg_lote'):
        if not math.isfinite(m[k]) or m[k]<0:raise ValueError('Material inválido: '+k)
    if m['objetivo_dias']<m['punto_pedido_dias']:raise ValueError('Objetivo de material menor que punto de pedido')
    if abs(sum(x['fraccion'] for x in c['edades_iniciales'])-1)>EPS or any(x['dias']<0 or x['fraccion']<0 for x in c['edades_iniciales']):raise ValueError('Edades iniciales inválidas')
    seen=set(); h=horas(c['fin'],c['inicio'])
    for o in pedidos:
        if o['id'] in seen or o['id'].startswith('INICIAL_'):raise ValueError('Identificador duplicado o reservado')
        seen.add(o['id'])
        if o['group'] not in ids or not all(math.isfinite(o[k]) for k in ('qty','arrival','due')) or o['qty']<=0 or not 0<=o['arrival']<h or o['due']<o['arrival']:raise ValueError('Pedido inválido: '+str(o))

class Modelo:
    def __init__(self, config, mts_groups, pedidos, detalle=False):
        validar(config,pedidos,mts_groups)
        self.c=copy.deepcopy(config); self.p=self.c['parametros']; self.m=self.c['materiales']
        self.grupos=self.c['grupos']; self.ids=[g['id'] for g in self.grupos]; self.mts=set(mts_groups)
        self.h=horas(self.c['fin'],self.c['inicio']); self.fin=self.h+24*self.c['seguimiento_dias']
        self.ventanas,self.meses=calendario(self.c,self.fin+24); self.env=simpy.Environment()
        self.detalle=detalle; self.eventos=[]; self.pedidos=[]; self.lotes=[]; self.fg={g:[] for g in self.ids};self.reservado=0.
        self.wip={g['id']:g['initial_wip'] for g in self.grupos}
        self.wip_inicial=[g for g in self.grupos if g['initial_wip']>EPS]
        self.ocupado=False; self.ultimo=0.; self.horas_usadas=0.; self.areas=defaultdict(float)
        self.areas_mes=defaultdict(lambda:defaultdict(float)); self.cierres=[]; self.despertares=set()
        self.pronostico=self.p['monthly_demand']/self.p['days']; self.objetivos={}
        self.mp_inicial=self.pronostico*self.m['cobertura_inicial_dias']/self.p['lot']
        self.mp=self.mp_inicial; self.mp_transito=0.; self.contador=defaultdict(float)
        for g in self.grupos:
            for edad in self.c['edades_iniciales']:
                q=g['initial_fg']*edad['fraccion']
                if q: self.fg[g['id']].append({'qty':q,'birth':-edad['dias']*24,'lot':'INICIAL'})
            if g['initial_backlog']:
                self.agendar(0,'pedido',{'id':'INICIAL_'+g['id'],'group':g['id'],'qty':g['initial_backlog'],'arrival':0.,'due':0.,'initial':True})
        for o in pedidos:self.agendar(o['arrival'],'pedido',o)
        for t in np.arange(0,self.fin+EPS,24):self.agendar(float(t),'revision')
        self.agendar(self.h,'corte');self.agendar(self.fin,'corte')
        for _,b,mes in self.meses:
            if b<=self.h+EPS:self.agendar(b,'cierre',mes)
        self.actualizar_objetivos()

    def agendar(self, t, tipo, dato=None):
        def evento():
            yield self.env.timeout(max(0,t-self.env.now))
            self.procesar(tipo,dato)
        self.env.process(evento())

    def stock(self, g):return sum(x['qty'] for x in self.fg[g])
    def abiertos(self,g):return [o for o in self.pedidos if o['group']==g and o['dispatch'] is None]
    def posicion(self,g):return self.stock(g)+self.wip[g]-sum(o['qty'] for o in self.abiertos(g))
    def estado(self):
        return {'fg_m2':sum(self.stock(g) for g in self.ids)+self.reservado,'reservado_m2':self.reservado,'wip_m2':sum(self.wip.values()),
                'mp_lotes':self.mp,'transito_m2':sum(o['qty'] for o in self.pedidos if o['dispatch'] is not None and o['delivery'] is None),
                'pendiente_m2':sum(o['qty'] for o in self.pedidos if o['delivery'] is None)}

    def registrar(self,tipo,g='',q=0.,pedido='',lote='',nota=''):
        if self.detalle:self.eventos.append({'hora':self.env.now,'evento':tipo,'grupo':g,'cantidad_m2':q,'pedido':pedido,'lote':lote,'nota':nota,**self.estado()})

    def integrar(self,t):
        # La cantidad permanece constante entre eventos. Área exacta, no media de extremos.
        valores=self.estado(); valores.update({'fg_'+g:self.stock(g) for g in self.ids})
        dt=max(0,min(t,self.h)-min(self.ultimo,self.h))
        for k,v in valores.items():self.areas[k]+=v*dt
        if self.ocupado:self.horas_usadas+=dt
        for a,b,mes in self.meses:
            dur=max(0,min(t,b,self.h)-max(self.ultimo,a))
            if dur:
                for k,v in valores.items():self.areas_mes[mes][k]+=v*dur
        self.ultimo=t

    def actualizar_objetivos(self):
        horizonte=self.p['planning_lead_days']+1; z=NormalDist().inv_cdf(self.p['cycle_probability'])
        for g in self.grupos:
            mu=self.pronostico*g['share']; var=mu/self.p['order_mean']*(self.p['order_sd']**2+self.p['order_mean']**2)
            self.objetivos[g['id']]=math.ceil((mu*horizonte+z*math.sqrt(var*horizonte))/self.p['lot'])*self.p['lot']

    def procesar(self,tipo,dato):
        t=self.env.now
        if tipo=='pedido':
            self.pedidos.append({**dato,'dispatch':None,'delivery':None})
            self.registrar('pedido',dato['group'],dato['qty'],dato['id'],nota=f"Vence a las {dato['due']:.6f} h")
        elif tipo=='fin_proceso':
            self.ocupado=False; dato['fin_proceso']=t
            self.agendar(t+self.p['quality_hours'],'calidad',dato)
            self.registrar('fin_proceso',dato['grupo'],dato['qty'],lote=dato['id'])
        elif tipo=='calidad':
            g=dato['grupo']; q=dato['qty']; self.wip[g]-=q
            self.fg[g].append({'qty':q,'birth':t,'lot':dato['id']}); dato['alta']=t
            self.contador['altas']+=q
            if dato['modo']=='WIP inicial':self.contador['wip_inicial_terminado']+=q
            else:self.contador['produccion_nueva']+=q
            self.registrar('alta_stock',g,q,lote=dato['id'],nota=dato['modo'])
        elif tipo=='entrega':
            dato['delivery']=t; self.contador['entregado']+=dato['qty']
            self.registrar('entrega',dato['group'],dato['qty'],dato['id'],nota='A tiempo' if t<=dato['due']+EPS else 'Tardía')
        elif tipo=='material':
            self.mp+=dato; self.mp_transito-=dato; self.contador['mp_recibido']+=dato
            self.registrar('recepcion_mp',nota=f'{dato} lotes de receta')
        elif tipo=='revision':
            if t>0:
                observado=sum(o['qty'] for o in self.pedidos if not o.get('initial') and t-24<=o['arrival']<t)
                beta=self.p['forecast_smoothing'];self.pronostico=(1-beta)*self.pronostico+beta*observado
                self.actualizar_objetivos()
            self.comprar_material()
            self.registrar('revision',nota=f'Pronóstico {self.pronostico:.6f} m2/día')
        elif tipo=='despertar':self.despertares.discard(t)
        # El cierre se toma después de altas y despachos simultáneos.

    def comprar_material(self):
        if not self.m['limitados'] or not self.m['compra_automatica']:return
        pos=self.mp+self.mp_transito; base=self.pronostico/self.p['lot']
        punto=base*self.m['punto_pedido_dias']; objetivo=base*self.m['objetivo_dias']
        if self.env.now>=self.h:
            objetivo=sum(math.ceil(max(0,-self.posicion(g))/self.p['lot']) for g in self.ids)
            punto=objetivo
        if pos+EPS<punto:
            q=max(0,math.ceil(objetivo-pos-EPS)); self.mp_transito+=q
            self.agendar(self.env.now+self.m['plazo_dias']*24,'material',q)
            self.registrar('compra_mp',nota=f'{q} lotes de receta; plazo {self.m["plazo_dias"]} días')

    def despachar(self):
        bloqueados=set()
        for o in sorted(self.pedidos,key=lambda x:(x['due'],x['arrival'],x['id'])):
            g=o['group']
            if o['dispatch'] is not None or g in bloqueados:continue
            if self.stock(g)+EPS<o['qty']:bloqueados.add(g);continue
            falta=o['qty']
            for lote in sorted(self.fg[g],key=lambda x:x['birth']):
                tomar=min(lote['qty'],falta); lote['qty']-=tomar; falta-=tomar;self.reservado+=tomar
                if tomar>EPS:self.registrar('asignacion',g,tomar,o['id'],lote['lot'])
                if falta<=EPS:break
            self.fg[g]=[x for x in self.fg[g] if x['qty']>EPS]
            o['dispatch']=self.env.now; self.contador['despachado']+=o['qty'];self.reservado-=o['qty']
            self.agendar(self.env.now+self.p['transport_hours'],'entrega',o)
            self.registrar('despacho',g,o['qty'],o['id'])

    def decidir(self):
        t=self.env.now
        if self.ocupado or t>=self.fin-EPS:return
        if self.wip_inicial:
            g=self.wip_inicial[0]; gid=g['id']; q=g['initial_wip']; modo='WIP inicial'
            dur=q*self.p['wip_remaining_fraction']/self.p['net_rate']
        else:
            candidatos=[]
            for i,g in enumerate(self.grupos):
                gid=g['id']; ip=self.posicion(gid); mts=gid in self.mts
                objetivo=self.objetivos[gid] if mts and t<self.h else 0
                if objetivo-ip<=EPS:continue
                due=min((o['due'] for o in self.abiertos(gid)),default=float('inf'))
                media=self.p['monthly_demand']/self.p['days']*g['share']
                cobertura=(self.stock(gid)-sum(o['qty'] for o in self.abiertos(gid)))/media if media else float('inf')
                candidatos.append(((0 if ip<-EPS else 1,due if ip<-EPS else cobertura,i),gid,mts))
            if not candidatos:return
            _,gid,mts=min(candidatos);q=self.p['lot'];dur=q/self.p['net_rate'];modo='MTS' if mts else 'MTO'
            if self.m['limitados'] and self.mp+EPS<1:return
        inicio=next((max(t,a) for a,b in self.ventanas if max(t,a)+dur<=b+EPS),None)
        if inicio is None or inicio>=self.fin:return
        if inicio>t+EPS:
            if inicio not in self.despertares:self.despertares.add(inicio);self.agendar(inicio,'despertar')
            return
        if modo=='WIP inicial':self.wip_inicial.pop(0)
        else:
            if not self.m['limitados']:
                # Modo de regresión: suministro inmediato, siempre contabilizado.
                self.mp+=1;self.contador['mp_recibido']+=1
            self.mp-=1;self.contador['mp_consumido']+=1;self.wip[gid]+=q
            self.contador['iniciado']+=q;self.contador['iniciado_'+modo]+=q
        self.ocupado=True
        lote={'id':f'L{len(self.lotes)+1:04d}','grupo':gid,'qty':q,'modo':modo,'inicio':t,'duracion':dur,'fin_proceso':None,'alta':None}
        self.lotes.append(lote);self.agendar(t+dur,'fin_proceso',lote)
        self.registrar('inicio',gid,q,lote=lote['id'],nota=modo)

    def ejecutar_hasta(self,limite):
        while self.env.peek()<=limite+EPS:
            t=self.env.peek();self.integrar(t)
            while self.env.peek()<=t+EPS:self.env.step()
            self.despachar()
            # Entrega de duración cero también debe completarse en ese instante.
            if self.env.peek()<=t+EPS:continue
            for a,b,mes in self.meses:
                if abs(t-b)<EPS and b<=self.h+EPS and not any(x['mes']==mes for x in self.cierres):
                    self.cierres.append({'mes':mes,**self.estado(),'produccion_acum_m2':self.contador['produccion_nueva'],**{'fg_'+g:self.stock(g) for g in self.ids}})
            if t<limite-EPS:self.decidir()
        self.integrar(limite)

    def resumen(self):
        nuevos=[o for o in self.pedidos if not o.get('initial')]
        vencidos=[o for o in nuevos if o['due']<=self.h+EPS]
        a_tiempo=[o for o in vencidos if o['delivery'] is not None and o['delivery']<=o['due']+EPS]
        completos=[o for o in nuevos if o['delivery'] is not None and o['delivery']<=self.h+EPS]
        pendientes=[o for o in nuevos if o['delivery'] is None]
        lead=[(o['delivery']-o['arrival'])/24 for o in completos]
        edades=[(self.h-o['arrival'])/24 for o in pendientes]
        stock=sum(self.stock(g) for g in self.ids); avg=self.areas['fg_m2']/self.h
        capacidad=sum(max(0,min(b,self.h)-a) for a,b in self.ventanas if a<self.h)
        producido=self.contador['produccion_nueva']; wip0=sum(g['initial_wip'] for g in self.grupos)
        fg0=sum(g['initial_fg'] for g in self.grupos)
        balance_fg=fg0+self.contador['altas']-self.contador['despachado']-stock
        balance_wip=wip0+self.contador['iniciado']-self.contador['altas']-sum(self.wip.values())
        balance_mp=self.mp_inicial+self.contador['mp_recibido']-self.contador['mp_consumido']-self.mp
        def ratio(a,b):return a/b if b else None
        edades_stock=[]
        for g in self.ids:
            for x in self.fg[g]:edades_stock.append({'grupo':g,'lote':x['lot'],'m2':x['qty'],'edad_dias':(self.h-x['birth'])/24})
        met={'fg_promedio_m2':avg,'fg_final_m2':stock,'wip_promedio_m2':self.areas['wip_m2']/self.h,'wip_final_m2':sum(self.wip.values()),
             'mp_promedio_lotes':self.areas['mp_lotes']/self.h,'mp_final_lotes':self.mp,'mp_cuerpo_final_kg':self.mp*self.m['cuerpo_kg_lote'],'mp_esmalte_final_kg':self.mp*self.m['esmalte_kg_lote'],
             'produccion_m2':producido,'lotes_iniciados':sum(x['modo']!='WIP inicial' for x in self.lotes),
             'otif_pct':100*ratio(len(a_tiempo),len(vencidos)) if vencidos else None,'pedidos_vencidos':len(vencidos),'pedidos_otif':len(a_tiempo),
             'fill_plazo_pct':100*ratio(sum(o['qty'] for o in a_tiempo),sum(o['qty'] for o in vencidos)) if vencidos else None,
             'fill_cierre_pct':100*ratio(sum(o['qty'] for o in completos),sum(o['qty'] for o in nuevos)) if nuevos else None,
             'lead_dias':float(np.mean(lead)) if lead else None,'lead_p90_dias':float(np.percentile(lead,90)) if lead else None,
             'pedidos_nuevos':len(nuevos),'pedidos_entregados':len(completos),'pendientes_nuevos':len(pendientes),
             'pendiente_nuevo_m2':sum(o['qty'] for o in pendientes),'pendiente_total_m2':self.estado()['pendiente_m2'],
             'edad_pendiente_media_dias':float(np.mean(edades)) if edades else 0.,'edad_pendiente_p90_dias':float(np.percentile(edades,90)) if edades else 0.,
             'utilizacion_pct':100*ratio(self.horas_usadas,capacidad) if capacidad else None,'horas_usadas':self.horas_usadas,'horas_disponibles':capacidad,
             'despachado_m2':self.contador['despachado'],'entregado_m2':self.contador['entregado'],'demanda_nueva_m2':sum(o['qty'] for o in nuevos),
             'transito_m2':self.estado()['transito_m2'],'rotacion_periodo':ratio(self.contador['despachado'],avg),
             'fraccion_mts_real':ratio(self.contador['iniciado_MTS'],self.contador['iniciado']),
             'fg_mayor_180_dias_m2':sum(x['m2'] for x in edades_stock if x['edad_dias']>180),
             'fg_valor_promedio_ARS':avg*self.p['unit_cost'],
             'balance_fg_m2':balance_fg,'balance_wip_m2':balance_wip,'balance_mp_lotes':balance_mp,
             'balance_transito_m2':self.contador['despachado']-self.contador['entregado']-self.estado()['transito_m2']}
        for g in self.ids:met['fg_final_'+g]=self.stock(g)
        if max(abs(balance_fg),abs(balance_wip),abs(balance_mp),abs(met['balance_transito_m2']))>1e-5:raise ArithmeticError('Balance abierto')
        if stock<-EPS or self.mp<-EPS or any(v<-EPS for v in self.wip.values()):raise ArithmeticError('Existencia negativa')
        return met,edades_stock

    def correr(self):
        self.ejecutar_hasta(self.h)
        met,edades=self.resumen();pedidos_cierre=copy.deepcopy(self.pedidos);lotes_cierre=copy.deepcopy(self.lotes)
        for fila in self.cierres:
            a,b,_=next(x for x in self.meses if x[2]==fila['mes'])
            fila.update({k+'_promedio':v/(b-a) for k,v in self.areas_mes[fila['mes']].items()})
        if self.fin>self.h:
            self.decidir();self.ejecutar_hasta(self.fin)
        met['pendientes_tras_seguimiento']=sum(o['delivery'] is None for o in self.pedidos if not o.get('initial'))
        met['pendiente_m2_tras_seguimiento']=sum(o['qty'] for o in self.pedidos if not o.get('initial') and o['delivery'] is None)
        return {'version':VERSION,'resumen':met,'pedidos':pedidos_cierre,'pedidos_seguimiento':self.pedidos,
                'eventos':self.eventos,'lotes':lotes_cierre,'mensual':self.cierres,'edades':edades}

def simular(config,mts_groups,pedidos,detalle=False):
    return Modelo(config,mts_groups,pedidos,detalle).correr()
