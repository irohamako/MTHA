"""Pedidos fechados: una realización se comparte entre todas las políticas."""
from datetime import datetime
import math
import numpy as np

def horas(fecha, inicio):
    return (datetime.fromisoformat(fecha)-datetime.fromisoformat(inicio)).total_seconds()/3600

def generar(config, semilla=20260925, replica=0):
    # Flujos separados: cambiar el calendario no altera tamaños ni grupos.
    rng=[np.random.default_rng(np.random.SeedSequence([semilla,replica,k])) for k in range(4)]
    p=config['parametros']; media=p['order_mean']; sd=p['order_sd']
    sigma=math.sqrt(math.log1p((sd/media)**2)); mu=math.log(media)-sigma*sigma/2
    grupos=[g['id'] for g in config['grupos']]; shares=[g['share'] for g in config['grupos']]
    plazos={g['id']:g['deadline_days']*24 for g in config['grupos']}; pedidos=[]
    for fila in config['demanda_mensual']:
        ini=datetime.fromisoformat(fila['mes']+'-01'); siguiente=datetime(ini.year+(ini.month==12),ini.month%12+1,1)
        t0=horas(ini.isoformat(),config['inicio']); dur=(siguiente-ini).total_seconds()/3600
        n=int(rng[0].poisson(fila['m2']/media))
        cantidades=rng[1].lognormal(mu,sigma,n); llegadas=np.sort(rng[2].uniform(t0,t0+dur,n))
        asignaciones=rng[3].choice(grupos,n,p=shares)
        for cantidad,llegada,g in zip(cantidades,llegadas,asignaciones):
            pedidos.append({'id':f'P{len(pedidos)+1:04d}','group':str(g),'arrival':float(llegada),
                            'qty':float(cantidad),'due':float(llegada+plazos[g])})
    return pedidos
