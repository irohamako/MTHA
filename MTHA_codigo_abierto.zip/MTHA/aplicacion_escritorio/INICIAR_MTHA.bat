@echo off
setlocal
cd /d "%~dp0"
title MTH-A - Inicio
if exist ".venv\Scripts\python.exe" goto check
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys,tkinter; assert sys.version_info >= (3,11)" >nul 2>nul
  if not errorlevel 1 (
    py -3 -m venv .venv >instalacion.log 2>&1
    goto ready
  )
)
where python >nul 2>nul
if not errorlevel 1 (
  python -c "import sys,tkinter; assert sys.version_info >= (3,11)" >nul 2>nul
  if not errorlevel 1 (
    python -m venv .venv >instalacion.log 2>&1
    goto ready
  )
)
echo Instala Python de 64 bits, version 3.12 o 3.13, con Tcl/Tk.
echo Marca Add python.exe to PATH en el instalador.
echo Sitio oficial: https://www.python.org/downloads/windows/
echo Despues volve a abrir INICIAR_MTHA.bat.
goto finish
:ready
if not exist ".venv\Scripts\python.exe" goto fail
:check
".venv\Scripts\python.exe" -c "import tkinter,numpy,scipy,simpy" >nul 2>nul
if not errorlevel 1 goto run
echo Preparando MTH-A. Solo la primera instalacion necesita Internet.
".venv\Scripts\python.exe" -m pip install -r requirements.txt >>instalacion.log 2>&1
if errorlevel 1 goto fail
:run
echo Abriendo MTH-A. Esta es una aplicacion de escritorio.
".venv\Scripts\python.exe" app.py >ejecucion_inicio.log 2>&1
if errorlevel 1 goto fail
exit /b 0
:fail
echo No se pudo iniciar. Revisa instalacion.log y ejecucion_inicio.log.
echo Comparti el mensaje de error para poder resolverlo.
:finish
pause
