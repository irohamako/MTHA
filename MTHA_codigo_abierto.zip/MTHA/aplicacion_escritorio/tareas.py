"""Ejecución aislada: la ventana permanece disponible mientras calcula."""
import sys,json,copy,traceback,csv,math
from pathlib import Path
from datetime import datetime,timedelta
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'motor'))
from datos import prepare,months

def write(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(path)
def csvout(path,rows):
    if not rows:return
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter=';');w.writeheader();w.writerows(rows)

def run(folder,kind):
    import evaluacion as e
    import numpy as np
    p=prepare(json.loads((folder/'proyecto.json').read_text(encoding='utf-8')));c=p['operacion'];n=p['replicas']
    e.NOPS=p['meses'];e.START=datetime.fromisoformat(c['inicio'])
    cash_months=3
    latest=datetime.fromisoformat(c['fin'])+timedelta(days=30+max(p['economia']['dso_days'],p['economia']['dpo_days']))
    while datetime.fromisoformat(months(p['inicio'],p['meses']+cash_months+1)[-1]+'-01')<=latest:cash_months+=1
    e.DATES=[datetime.fromisoformat(m+'-01') for m in months(p['inicio'],p['meses']+cash_months+1)]
    e.BOUNDS=np.array([(d-e.START).total_seconds()/3600 for d in e.DATES]);e.MONTHS=[d.strftime('%Y-%m') for d in e.DATES[:-1]];e.NMONTH=len(e.MONTHS)
    e.P.update(p['precios']);e.COST=p['costos']
    if kind=='demanda':
        samples=[];detail=[];monthly=[]
        for i in range(n):
            orders=e.generar(c,p['semilla'],i);totals=[]
            for mo in c['demanda_mensual']:
                a=e.month((datetime.fromisoformat(mo['mes']+'-01')-e.START).total_seconds()/3600)
                selected=[o for o in orders if e.month(o['arrival'])==a]
                total=sum(x['qty'] for x in selected);totals.append(total);samples.append({'replica':i+1,'mes':mo['mes'],'pedidos':len(selected),'demanda_m2':total})
            if i==0:detail=orders
            write(folder/'avance.json',{'avance':i+1,'total':n})
        for mo in c['demanda_mensual']:
            vals=[r['demanda_m2'] for r in samples if r['mes']==mo['mes']]
            lo,hi=np.quantile(vals,[.025,.975]);ci=e.ci(vals)
            monthly.append({'mes':mo['mes'],'objetivo':mo['m2'],'media':ci['media'],'p025':float(lo),'p975':float(hi),'ic_inferior':ci['inferior'] if n>1 else None,'ic_superior':ci['superior'] if n>1 else None})
        csvout(folder/'replicas_demanda.csv',samples);csvout(folder/'pedidos_ejemplo.csv',detail);csvout(folder/'demanda_mensual.csv',monthly)
        write(folder/'resumen.json',{'tipo':'demanda','mensual':monthly,'replicas':n,'semilla':p['semilla']});return
    pct=sum(g['share'] for g in c['grupos'] if g['id'] in p['grupos_mts'])*100
    hybrid='H'+format(pct,'.6g');policies=[{'id':'MTS100','mts_groups':[g['id'] for g in c['grupos']]},{'id':hybrid,'mts_groups':p['grupos_mts']}]
    rows=[];monthly=[];diff=[];flow=[]
    for i in range(n):
        orders=e.generar(c,p['semilla'],i);pair=[]
        for pol in policies:
            raw=e.raw_run(c,pol,orders);detail=raw.pop('detalle');econ=e.economics(raw,p['economia']);pair.append(econ)
            rows.append({'politica':pol['id'],'replica':i+1,**econ['metricas']})
            for j,mo in enumerate(e.MONTHS):monthly.append({'politica':pol['id'],'replica':i+1,'mes':mo,**{k:v[j] for k,v in econ['mensual'].items()}})
            if i==0:
                write(folder/f'detalle_{pol["id"]}.json',detail)
                csvout(folder/f'eventos_{pol["id"]}.csv',detail['eventos'])
                csvout(folder/f'pedidos_{pol["id"]}.csv',detail['pedidos_seguimiento'])
        diff.append(pair[1]['metricas']['van_pre_ganancias']-pair[0]['metricas']['van_pre_ganancias'])
        flow.append([b-a for a,b in zip(pair[0]['flujo_valorado'],pair[1]['flujo_valorado'])])
        write(folder/'avance.json',{'avance':i+1,'total':n})
    csvout(folder/'replicas.csv',rows);csvout(folder/'mensual.csv',monthly)
    keys=['fg_promedio_m2','otif_pct','lead_dias','pendiente_total_m2','utilizacion_pct','resultado_operativo_10m','nct_diciembre','costo_industrial_10m']
    keys=[k for k in keys if k in rows[0]]
    avg={pol['id']:{k:float(np.mean([r[k] for r in rows if r['politica']==pol['id'] and r[k] is not None])) if any(r[k] is not None for r in rows if r['politica']==pol['id']) else None for k in keys} for pol in policies}
    mf=np.mean(flow,axis=0).tolist();inv=pair[1]['metricas']['inversion_inicial']
    series={pol['id']:[float(np.mean([r['fg_promedio'] for r in monthly if r['politica']==pol['id'] and r['mes']==mo['mes']])) for mo in c['demanda_mensual']] for pol in policies}
    result={'tipo':'comparacion','politica':hybrid,'replicas':n,'semilla':p['semilla'],'van':e.ci(diff),'roi':sum(mf)/inv*100 if inv else None,'flujo':mf,'medias':avg,'series':series,'meses':[m['mes'] for m in c['demanda_mensual']],'error_balance':max(r['balance_caja_max'] for r in rows)}
    write(folder/'resumen.json',result)

if __name__=='__main__':
    folder=Path(sys.argv[1])
    try:run(folder,sys.argv[2])
    except Exception:
        err=traceback.format_exc();(folder/'diagnostico.txt').write_text(err,encoding='utf-8');write(folder/'error.json',{'error':str(sys.exc_info()[1])});sys.exit(1)
