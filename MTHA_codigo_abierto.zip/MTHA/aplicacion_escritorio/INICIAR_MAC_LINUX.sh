#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -c 'import tkinter' || { echo 'Instala Python con soporte Tk para abrir la ventana.'; exit 1; }
if [ ! -x .venv/bin/python ]; then python3 -m venv .venv; fi
if ! .venv/bin/python -c 'import numpy,scipy,simpy' >/dev/null 2>&1; then
 .venv/bin/python -m pip install -r requirements.txt
fi
.venv/bin/python app.py
