"""MTH-A · etapa 1: datos y diagnóstico de familias."""
VERSION = "1.0.0"
