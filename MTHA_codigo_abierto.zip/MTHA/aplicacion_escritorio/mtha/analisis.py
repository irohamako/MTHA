"""Cálculos deterministas. Biblioteca estándar; no completa datos faltantes.

Los parámetros de negocio se leen únicamente de PARAMETROS_MTHA.
Las constantes numéricas de este módulo son matemáticas o conversiones de unidad.
"""
import calendar
import csv
import hashlib
import io
import json
import math
import statistics
from datetime import datetime, timezone

from . import VERSION

SCHEMAS = {
    "FAMILIAS": ["familia_id", "nombre", "formato", "acabado", "unidad", "moneda", "base_precios", "tipo_dato", "fuente"],
    "DEMANDA": ["familia_id", "mes", "demanda_m2", "despachado_m2", "numero_pedidos", "tipo_dato", "fuente"],
    "INVENTARIO": ["familia_id", "mes", "stock_inicio_m2", "stock_fin_m2", "stock_promedio_m2", "tipo_dato", "fuente"],
    "PARAMETROS_MTHA": ["familia_id", "parametro", "valor", "unidad", "modo", "normalizado", "min_real", "max_real", "tipo_dato", "fuente", "justificacion", "fecha_fuente"],
}

# nombre: unidad, mínimo, máximo (None = sin límite superior), origen sugerido.
PARAMS = {
    "costo_unitario": ("moneda/m2", 0, None, "Contabilidad o ficha de costo de producto terminado; indicar moneda y base de precios."),
    "tasa_mantenimiento_anual": ("fraccion/anio", 0, None, "Finanzas y depósito: tasa anual total; aclarar qué componentes incluye."),
    "capacidad_efectiva_m2_h": ("m2/h", 0, None, "Producción/planificación: salida buena por hora programada, con pérdidas habituales ya descontadas."),
    "horas_asignadas_mes": ("h/mes", 0, None, "Plan mensual: horas programadas asignadas a esta familia, sin duplicarlas entre familias."),
    "lead_time_mto_sin_cola_dias": ("dias", 0, None, "Tiempos administrativos + fabricación + despacho + transporte, sin espera por cola; hornero/logística/planificación."),
    "lead_time_cliente_dias": ("dias", 0, None, "Pedidos, acuerdos comerciales o responsable de ventas: plazo aceptado por el cliente."),
    "lote_minimo_m2": ("m2", 0, None, "Planificación: tamaño mínimo técnicamente viable; será usado en la simulación siguiente."),
    "setup_h": ("h/cambio", 0, None, "Registro de cambios de formato/producto o estimación documentada del operario; siguiente simulación."),
}
TIPOS = {"real", "estimado", "sintetico"}


class InputError(ValueError):
    pass


def number(value, label, required=False):
    """Coma o punto decimal; nunca separadores de miles ni NaN/Infinity."""
    s = str(value if value is not None else "").strip()
    if not s:
        if required:
            raise InputError(f"{label}: falta el valor.")
        return None
    if "," in s and "." in s:
        raise InputError(f"{label}: usá decimales sin separador de miles (ejemplo: 1234,5).")
    try:
        result = float(s.replace(",", "."))
    except ValueError:
        raise InputError(f"{label}: '{s}' no es un número válido.") from None
    if not math.isfinite(result) or result < 0:
        raise InputError(f"{label}: debe ser un número finito mayor o igual a cero.")
    return result


def month(value):
    try:
        x = datetime.strptime(str(value), "%Y-%m")
        if x.strftime("%Y-%m") != value:
            raise ValueError
        return x.year, x.month
    except (ValueError, TypeError):
        raise InputError(f"Mes '{value}' inválido: usar AAAA-MM, por ejemplo 2024-05.") from None


def months_between(start, end):
    sy, sm = month(start)
    ey, em = month(end)
    a, b = sy * 12 + sm - 1, ey * 12 + em - 1
    if b < a:
        raise InputError("El mes final debe ser igual o posterior al inicial.")
    if b - a > 1200:
        raise InputError("El período supera 100 años; revisá las fechas.")
    return [f"{i // 12:04d}-{i % 12 + 1:02d}" for i in range(a, b + 1)]


def days(m):
    return calendar.monthrange(*month(m))[1]


def read_csv(text, table):
    if not isinstance(text, str):
        raise InputError(f"{table}: se esperaba texto CSV.")
    text = text.lstrip("\ufeff").strip()
    if not text:
        return []
    first = text.splitlines()[0]
    sep = max([";", "\t", ","], key=lambda c: first.count(c))
    reader = csv.DictReader(io.StringIO(text), delimiter=sep)
    headers = [x.strip() for x in (reader.fieldnames or [])]
    if len(set(headers)) != len(headers):
        raise InputError(f"{table}: hay encabezados repetidos.")
    missing = set(SCHEMAS[table]) - set(headers)
    extra = set(headers) - set(SCHEMAS[table])
    if missing or extra:
        raise InputError(f"{table}: encabezados faltantes {sorted(missing)}; no reconocidos {sorted(extra)}. Usá la plantilla.")
    reader.fieldnames = headers
    rows = []
    for i, r in enumerate(reader, 2):
        if None in r or any(v is None for v in r.values()):
            raise InputError(f"{table}, fila {i}: cantidad de celdas distinta al encabezado.")
        r = {k: v.strip() for k, v in r.items()}
        if any(r.values()):
            rows.append(r)
    return rows


def csv_text(rows, columns=None):
    cols = columns or (list(rows[0]) if rows else [])
    buf = io.StringIO(newline="")
    writer = csv.DictWriter(buf, fieldnames=cols, delimiter=";", lineterminator="\n", extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        # Texto literal seguro al abrir exportaciones en planillas.
        safe = {}
        for k in cols:
            v = row.get(k, "")
            if isinstance(v, (dict, list)):
                v = json.dumps(v, ensure_ascii=False)
            if isinstance(v, str) and v.startswith(("=", "+", "-", "@")):
                v = "'" + v
            safe[k] = v
        writer.writerow(safe)
    return "\ufeff" + buf.getvalue()


def resolved_parameter(row):
    key = row["parametro"]
    if key not in PARAMS:
        raise InputError(f"Parámetro desconocido: {key}.")
    unit, low, high, _ = PARAMS[key]
    if row["unidad"] != unit:
        raise InputError(f"{key}: la unidad debe ser '{unit}'.")
    mode = row["modo"] or "directo"
    if mode not in {"directo", "lineal", "log"}:
        raise InputError(f"{key}: modo debe ser directo, lineal o log.")
    if mode == "directo":
        value = number(row["valor"], key)
        if value is None:
            return None
    else:
        if row["valor"]:
            raise InputError(f"{key}: dejá 'valor' vacío cuando uses normalización.")
        z = number(row["normalizado"], key + " normalizado", True)
        a = number(row["min_real"], key + " mínimo", True)
        b = number(row["max_real"], key + " máximo", True)
        if not 1 <= z <= 100 or b <= a or (mode == "log" and a <= 0):
            raise InputError(f"{key}: normalizado entre 1 y 100, máximo > mínimo; log exige mínimo > 0.")
        if not row["justificacion"]:
            raise InputError(f"{key}: explicá y documentá el rango en justificacion.")
        value = a + (z - 1) / 99 * (b - a) if mode == "lineal" else math.exp(math.log(a) + (z - 1) / 99 * math.log(b / a))
    if value < low or (high is not None and value > high):
        raise InputError(f"{key}: valor fuera de límites físicos.")
    return value


def normalized_value(value, a, b, mode="lineal"):
    if b <= a or not a <= value <= b:
        raise InputError("Valor fuera del rango; revisar el rango sin recortar el dato.")
    if mode == "lineal":
        return 1 + 99 * (value - a) / (b - a)
    if mode == "log" and a > 0:
        return 1 + 99 * math.log(value / a) / math.log(b / a)
    raise InputError("Normalización no válida.")


def analyze(payload):
    if not isinstance(payload, dict) or not isinstance(payload.get("tables"), dict):
        raise InputError("Falta el proyecto con sus tablas.")
    period = months_between(payload.get("inicio", ""), payload.get("fin", ""))
    tables = {t: read_csv(payload["tables"].get(t, ""), t) for t in SCHEMAS}
    families = {r["familia_id"]: r for r in tables["FAMILIAS"]}
    if not families:
        raise InputError("Cargá al menos una familia en FAMILIAS.")
    if len(families) != len(tables["FAMILIAS"]):
        raise InputError("FAMILIAS: hay familia_id repetidos.")
    warnings, trace = [], []
    parsed = {"DEMANDA": {}, "INVENTARIO": {}, "PARAMETROS_MTHA": {}}
    fields = {"DEMANDA": ["demanda_m2", "despachado_m2", "numero_pedidos"], "INVENTARIO": ["stock_inicio_m2", "stock_fin_m2", "stock_promedio_m2"]}
    for t, rows in tables.items():
        seen = set()
        for idx, r in enumerate(rows, 2):
            fid = r["familia_id"]
            if not fid or fid not in families:
                raise InputError(f"{t}, fila {idx}: familia_id vacío o no registrado en FAMILIAS.")
            active = t != "PARAMETROS_MTHA" or bool(r["valor"] or r["normalizado"])
            if active and (r["tipo_dato"] not in TIPOS or not r["fuente"]):
                raise InputError(f"{t}, fila {idx}: indicá tipo_dato (real, estimado, sintetico) y fuente.")
            trace.append({"tabla": t, "fila": idx, **r})
            if t == "FAMILIAS":
                if not r["nombre"] or r["unidad"] != "m2":
                    raise InputError(f"Familia {fid}: completá nombre y unidad m2. Convertí cajas/piezas antes de cargar.")
                continue
            suffix = r["parametro"] if t == "PARAMETROS_MTHA" else r["mes"]
            key = (fid, suffix)
            if key in seen:
                raise InputError(f"{t}: registro duplicado para {fid} / {suffix}.")
            seen.add(key)
            if t == "PARAMETROS_MTHA":
                value = resolved_parameter(r)
                parsed[t][key] = value
                trace[-1]["valor_utilizado"] = value
                trace[-1]["formula"] = "valor" if (r["modo"] or "directo") == "directo" else ("min + (z-1)/99*(max-min)" if r["modo"] == "lineal" else "exp(log(min)+(z-1)/99*log(max/min))")
                if value is not None and r["tipo_dato"] != "real" and not r["justificacion"]:
                    raise InputError(f"{fid}/{suffix}: falta justificar el parámetro provisional.")
                if r["fecha_fuente"]:
                    try:
                        datetime.strptime(r["fecha_fuente"], "%Y-%m-%d")
                    except ValueError:
                        raise InputError(f"{fid}/{suffix}: fecha_fuente debe ser AAAA-MM-DD.") from None
            else:
                month(suffix)
                parsed[t][key] = {k: number(r[k], f"{t}, fila {idx}, {k}") for k in fields[t]}
                n = parsed[t][key].get("numero_pedidos")
                if n is not None and n != int(n):
                    raise InputError(f"{t}, fila {idx}: numero_pedidos debe ser entero.")
                d = parsed[t][key].get("demanda_m2")
                if n == 0 and d is not None and d > 0:
                    raise InputError(f"{t}, fila {idx}: demanda positiva con cero pedidos; revisá o dejá pedidos vacío.")
                if suffix not in period:
                    warnings.append(f"{t}: {fid}/{suffix} está fuera del período y no entra en los indicadores.")
    results, missing, series = [], [], []
    for fid, f in families.items():
        p = {k: parsed["PARAMETROS_MTHA"].get((fid, k)) for k in PARAMS}
        dem = {m: parsed["DEMANDA"].get((fid, m), {}) for m in period}
        inv = {m: parsed["INVENTARIO"].get((fid, m), {}) for m in period}
        obs = [r["demanda_m2"] for r in dem.values() if r.get("demanda_m2") is not None]
        absent = [m for m in period if dem[m].get("demanda_m2") is None]
        complete = len(obs) == len(period)
        mu = statistics.mean(obs) if complete else None
        sd = statistics.stdev(obs) if complete and len(obs) > 1 else None
        daily = sum(obs) / sum(days(m) for m in period) if complete else None
        avg_stocks, approx, unknown_stock = {}, [], []
        for m, r in inv.items():
            if r.get("stock_promedio_m2") is not None:
                avg_stocks[m] = r["stock_promedio_m2"]
            elif r.get("stock_inicio_m2") is not None and r.get("stock_fin_m2") is not None:
                avg_stocks[m] = (r["stock_inicio_m2"] + r["stock_fin_m2"]) / 2
                approx.append(m)
            else:
                unknown_stock.append(m)
            series.append({"familia_id": fid, "mes": m, "demanda_m2": dem[m].get("demanda_m2"), "despachado_m2": dem[m].get("despachado_m2"), "stock_promedio_m2": avg_stocks.get(m), "stock_metodo": "aproximacion_extremos" if m in approx else ("aportado" if m in avg_stocks else "dato_no_disponible")})
        stock = sum(v * days(m) for m, v in avg_stocks.items()) / sum(days(m) for m in period) if not unknown_stock else None
        stock_end = inv[period[-1]].get("stock_fin_m2")
        shipped = [r.get("despachado_m2") for r in dem.values()]
        outflow = sum(shipped) if all(v is not None for v in shipped) else None
        counts = [r.get("numero_pedidos") for r in dem.values()]
        orders = sum(counts) if all(v is not None for v in counts) else None
        cap = p["capacidad_efectiva_m2_h"] * p["horas_asignadas_mes"] if all(p[k] is not None for k in ("capacidad_efectiva_m2_h", "horas_asignadas_mes")) else None
        valued = stock is not None and p["costo_unitario"] is not None and bool(f["moneda"] and f["base_precios"])
        capital = stock * p["costo_unitario"] if valued else None
        cost_annual = capital * p["tasa_mantenimiento_anual"] if capital is not None and p["tasa_mantenimiento_anual"] is not None else None
        lt, promise = p["lead_time_mto_sin_cola_dias"], p["lead_time_cliente_dias"]
        slack = promise - lt if lt is not None and promise is not None else None
        notes = []
        if absent:
            notes.append("Faltan meses de demanda: " + ", ".join(absent) + ". No se interpretan como cero.")
        if approx:
            notes.append("Stock promedio aproximado mediante (inicio + fin)/2 en: " + ", ".join(approx) + ". No captura picos intermedios.")
        if cap == 0 and mu and mu > 0:
            notes.append("Capacidad asignada cero con demanda positiva: carga/capacidad no definida; revisar asignación.")
        if cap and mu is not None and mu > cap:
            notes.append("La demanda media supera la capacidad asignada declarada.")
        if slack is not None:
            notes.append("El plazo mínimo MTO supera el plazo del cliente." if slack < 0 else "El plazo mínimo MTO cabe en el plazo del cliente; falta comprobar colas y capacidad compartida.")
        if len(obs) < 2:
            notes.append("Se requieren al menos dos meses conocidos para la desviación muestral y el CV.")
        relevant_types = {r["tipo_dato"] for t, rs in tables.items() for r in rs if r["familia_id"] == fid and ("mes" not in r or r["mes"] in period) and r["tipo_dato"]}
        result = {
            "familia_id": fid, "familia": f["nombre"], "meses_esperados": len(period), "meses_con_demanda": len(obs),
            "demanda_total_m2": sum(obs) if complete else None,
            "demanda_media_mensual_m2": mu, "desviacion_mensual_m2": sd,
            "cv_mensual": sd / mu if sd is not None and mu > 0 else None,
            "meses_demanda_cero": obs.count(0) if complete else None,
            "demanda_media_diaria_m2": daily,
            "numero_pedidos_periodo": orders,
            "pedido_promedio_m2": sum(obs) / orders if complete and orders else None,
            "stock_promedio_m2": stock, "stock_promedio_metodo": "dato_no_disponible" if stock is None else ("incluye_aproximacion_extremos" if approx else "aportado"),
            "stock_fin_periodo_m2": stock_end,
            "cobertura_stock_promedio_dias": stock / daily if stock is not None and daily else None,
            "despachado_periodo_m2": outflow,
            "rotacion_periodo": outflow / stock if outflow is not None and stock else None,
            "capital_promedio": capital, "moneda": f["moneda"], "base_precios": f["base_precios"],
            "costo_mantenimiento_anual_equivalente": cost_annual,
            "capacidad_asignada_mensual_m2": cap,
            "carga_demanda_sobre_capacidad": mu / cap if mu is not None and cap else None,
            "holgura_mto_sin_cola_dias": slack,
            "tipos_datos": ", ".join(sorted(relevant_types)),
            "observaciones": " ".join(notes),
        }
        results.append(result)
        for label, needed, source, priority in [
            ("Demanda mensual", bool(absent), "Ventas/pedidos: una fila por familia y mes, incluyendo ceros confirmados.", "A"),
            ("Inventario mensual", bool(unknown_stock), "Depósito/ERP: promedio diario del mes, o inicio y fin como aproximación explícita.", "B"),
            ("Despachos mensuales", outflow is None, "Remitos/salidas de depósito del mismo período: habilita rotación.", "B"),
            ("Cantidad de pedidos", orders is None, "Listado de pedidos por fecha de ingreso; habilita tamaño medio de pedido.", "B"),
            ("Moneda y base de precios", not (f["moneda"] and f["base_precios"]), "Contabilidad: misma moneda y poder adquisitivo para comparar costos.", "B"),
        ]:
            if needed:
                missing.append({"familia_id": fid, "dato_faltante": label, "prioridad_esta_etapa": priority, "donde_buscar": source})
        for name, value in p.items():
            if value is None:
                missing.append({"familia_id": fid, "dato_faltante": name, "prioridad_esta_etapa": "C" if name in {"lote_minimo_m2", "setup_h"} else "B", "donde_buscar": PARAMS[name][3]})
    # Participación en volumen solo con todas las familias y meses completos.
    totals = [r["demanda_total_m2"] for r in results]
    total = sum(totals) if all(v is not None for v in totals) else None
    for r in results:
        r["participacion_volumen"] = r["demanda_total_m2"] / total if total else None
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return {
        "version": VERSION, "fecha_calculo_utc": datetime.now(timezone.utc).isoformat(),
        "inicio": period[0], "fin": period[-1], "sha256_entradas": hashlib.sha256(canonical).hexdigest(),
        "resultados": results, "faltantes": missing, "series": series, "trazabilidad": trace, "avisos": warnings,
        "alcance": "Diagnóstico determinista por familia. No simula colas, OTIF, fill rate ni selecciona proporción MTS/MTO.",
    }
