"""MTH-A: aplicación de escritorio, sin servidor ni navegador."""
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
from pathlib import Path
import json,copy,subprocess,sys,os,zipfile,math,calendar
from datetime import datetime,timedelta
from datos import Store,DATA,ROOT,new_project,prepare,number,months

FONT='Segoe UI' if sys.platform=='win32' else 'Helvetica'
BLUE='#74ACDF';NAVY='#16344A';BG='#F2F7FB';WHITE='#FFFFFF';GOLD='#E8B84C';INK='#233F52'

def fmt(v,n=2):
    if v is None:return '—'
    if isinstance(v,str):return v
    return f'{v:,.{n}f}'.replace(',','X').replace('.',',').replace('X','.')

class App(tk.Tk):
    def __init__(self):
        super().__init__();self.title('MTH-A · Gestión industrial');self.geometry(f'{min(1220,self.winfo_screenwidth()-40)}x{min(820,self.winfo_screenheight()-70)}');self.minsize(980,650);self.configure(bg=BG)
        self.store=Store();self.user=None;self.project=None;self.pid=None;self.proc=None;self.folder=None;self.result=None;self.commit=None;self.playing=False;self.last_page='inicio'
        st=ttk.Style(self);st.theme_use('clam');st.configure('.',font=(FONT,10),background=BG,foreground=INK)
        st.configure('TFrame',background=BG);st.configure('Card.TFrame',background=WHITE);st.configure('TLabel',background=BG)
        st.configure('Title.TLabel',font=(FONT,24,'bold'));st.configure('Sub.TLabel',font=(FONT,11),foreground='#526D80')
        st.configure('TButton',padding=(12,8),background='#E1EEF9',borderwidth=0);st.map('TButton',background=[('active','#C9E3F7')])
        st.configure('Primary.TButton',background=BLUE,foreground=NAVY,font=(FONT,10,'bold'));st.map('Primary.TButton',background=[('active','#A2CCEF')])
        st.configure('TEntry',fieldbackground=WHITE,padding=5);st.configure('Treeview',rowheight=29,background=WHITE,fieldbackground=WHITE);st.configure('Treeview.Heading',font=(FONT,10,'bold'),background='#DDEDFC',padding=7)
        self.status=tk.StringVar(value='MTH-A · Gestión industrial');self.protocol('WM_DELETE_WINDOW',self.close)
        self.login_page();self.after(400,self.poll)
    def safe(self,fn):
        try:return fn()
        except Exception as ex:messagebox.showerror('Revisar datos',str(ex),parent=self);return None
    def wipe(self):
        for w in self.winfo_children():w.destroy()
    def sun(self,parent,size=100):
        ca=tk.Canvas(parent,width=size,height=size,bg=WHITE,highlightthickness=0)
        cx=cy=size/2
        for i in range(24):
            a=i*math.pi/12;ca.create_line(cx+size*.25*math.cos(a),cy+size*.25*math.sin(a),cx+size*.42*math.cos(a),cy+size*.42*math.sin(a),fill=GOLD,width=3)
        ca.create_oval(cx-size*.24,cy-size*.24,cx+size*.24,cy+size*.24,fill=GOLD,outline=GOLD)
        return ca
    def login_page(self):
        self.wipe();self.commit=None
        tk.Frame(self,bg=BLUE,height=50).pack(fill='x');tk.Frame(self,bg=WHITE,height=22).pack(fill='x')
        box=tk.Frame(self,bg=WHITE,padx=36,pady=10);box.pack(expand=True)
        self.sun(box,60).pack();tk.Label(box,text='Bienvenido a MTH-A',font=(FONT,25,'bold'),bg=WHITE,fg=NAVY).pack(pady=8)
        tk.Label(box,text='Planificar · Producir · Evaluar',font=(FONT,12),bg=WHITE,fg='#52758F').pack(pady=(0,18))
        tabs=ttk.Notebook(box);tabs.pack(fill='x');login=ttk.Frame(tabs,padding=20);reg=ttk.Frame(tabs,padding=20);tabs.add(login,text='Ingresar');tabs.add(reg,text='Crear usuario')
        self.login_vars={};self.reg_vars={}
        for frame,fields,values in [(login,[('usuario','Usuario'),('clave','Contraseña')],self.login_vars),(reg,[('nombre','Nombre y apellido'),('empresa','Empresa'),('usuario','Usuario'),('clave','Contraseña (mínimo 8 caracteres)'),('confirmar','Repetir contraseña')],self.reg_vars)]:
            for i,(k,label) in enumerate(fields):
                ttk.Label(frame,text=label).grid(row=i,column=0,sticky='w',pady=5);v=tk.StringVar();values[k]=v;ttk.Entry(frame,textvariable=v,show='•' if k in ('clave','confirmar') else '',width=32).grid(row=i,column=1,pady=5,padx=10)
        def enter():
            self.user=self.store.login(self.login_vars['usuario'].get(),self.login_vars['clave'].get());ps=self.store.projects(self.user['id'])
            if ps:self.pid=ps[0]['id'];self.project=self.store.load(self.user['id'],self.pid)
            else:self.project=new_project();self.pid=self.store.save(self.user['id'],self.project)
            self.result=None;self.folder=None;self.shell();self.nav('inicio',False)
        def register():
            v={k:x.get() for k,x in self.reg_vars.items()}
            if v['clave']!=v['confirmar']:raise ValueError('Las contraseñas no coinciden.')
            self.store.register(v['nombre'],v['empresa'],v['usuario'],v['clave']);self.login_vars['usuario'].set(v['usuario']);self.login_vars['clave'].set('');tabs.select(login)
            messagebox.showinfo('Usuario creado','Ya podés ingresar con tu usuario y contraseña.',parent=self)
        ttk.Button(login,text='Ingresar a MTH-A',style='Primary.TButton',command=lambda:self.safe(enter)).grid(row=3,column=0,columnspan=2,sticky='ew',pady=15)
        ttk.Button(reg,text='Crear mi usuario',style='Primary.TButton',command=lambda:self.safe(register)).grid(row=6,column=0,columnspan=2,sticky='ew',pady=15)
        tk.Label(box,text='Cuenta local en esta computadora · No requiere correo ni conexión',bg=WHITE,fg='#607A8D',font=(FONT,9)).pack(pady=12)
        tk.Frame(self,bg=BLUE,height=50).pack(fill='x',side='bottom')
    def shell(self):
        self.wipe();top=tk.Frame(self,bg=BLUE,height=74);top.pack(fill='x');top.pack_propagate(False)
        tk.Label(top,text='MTH-A',font=(FONT,25,'bold'),bg=BLUE,fg=NAVY).pack(side='left',padx=24)
        tk.Label(top,text='Gestión industrial',font=(FONT,12),bg=BLUE,fg=NAVY).pack(side='left')
        tk.Label(top,text=f"{self.user['name']}  |  {self.user['company']}",bg=BLUE,fg=NAVY,font=(FONT,11)).pack(side='right',padx=24)
        body=ttk.Frame(self);body.pack(fill='both',expand=True)
        side=tk.Frame(body,bg=NAVY,width=204);side.pack(side='left',fill='y');side.pack_propagate(False)
        for key,label in [('inicio','Inicio'),('proyecto','Mi proyecto'),('demanda','Demanda'),('inventario','Inventario y capacidad'),('simulacion','Simulación'),('economia','Economía'),('datos','Importar y analizar'),('historial','Historial'),('ayuda','Ayuda')]:
            tk.Button(side,text=label,anchor='w',bg=NAVY,fg=WHITE,activebackground='#315C7B',activeforeground=WHITE,relief='flat',font=(FONT,11),padx=20,pady=12,command=lambda k=key:self.nav(k)).pack(fill='x')
        tk.Button(side,text='Cerrar sesión',bg='#315C7B',fg=WHITE,relief='flat',pady=12,command=lambda:self.safe(self.logout)).pack(side='bottom',fill='x',pady=12)
        self.container=ttk.Frame(body);self.container.pack(side='left',fill='both',expand=True)
        bottom=ttk.Frame(self,padding=(12,6));bottom.pack(fill='x');ttk.Label(bottom,textvariable=self.status).pack(side='left');self.progress=ttk.Progressbar(bottom,length=170);self.progress.pack(side='right')
    def nav(self,page,save=True):
        def go():
            if save and self.commit:self.commit();self.pid=self.store.save(self.user['id'],self.project,self.pid)
            self.commit=None;self.playing=False;self.last_page=page
            for w in self.container.winfo_children():w.destroy()
            canvas=tk.Canvas(self.container,bg=BG,highlightthickness=0);bar=ttk.Scrollbar(self.container,orient='vertical',command=canvas.yview);bar.pack(side='right',fill='y');canvas.pack(fill='both',expand=True);canvas.configure(yscrollcommand=bar.set)
            self.body=ttk.Frame(canvas,padding=24);win=canvas.create_window((0,0),window=self.body,anchor='nw');self.body.bind('<Configure>',lambda _:canvas.configure(scrollregion=canvas.bbox('all')));canvas.bind('<Configure>',lambda ev:canvas.itemconfigure(win,width=ev.width))
            def wheel(ev):
                if canvas.winfo_exists():canvas.yview_scroll(-1 if ev.delta>0 else 1,'units')
            canvas.bind('<MouseWheel>',wheel)
            getattr(self,'page_'+page)()
        self.safe(go)
    def title(self,text=None):
        # Tk title still works through wm_title.
        if text is not None:return self.wm_title(text)
        return self.wm_title()
    def heading(self,text,sub=''):
        ttk.Label(self.body,text=text,style='Title.TLabel').pack(anchor='w',pady=(0,6))
        if sub:ttk.Label(self.body,text=sub,style='Sub.TLabel',wraplength=820).pack(anchor='w',pady=(0,20))
    def note(self,text,parent=None):
        ttk.Label(parent or self.body,text=text,wraplength=820,justify='left',foreground='#526D80').pack(anchor='w',pady=10)
    def buttons(self,items,parent=None):
        row=ttk.Frame(parent or self.body);row.pack(fill='x',pady=12)
        for i,(label,fn) in enumerate(items):ttk.Button(row,text=label,style='Primary.TButton' if i==0 else 'TButton',command=lambda f=fn:self.safe(f)).pack(side='left',padx=(0,8))
        return row
    def fields(self,items,parent=None,cols=2):
        frame=ttk.Frame(parent or self.body);frame.pack(fill='x',pady=8);out={}
        for j,(key,label,value) in enumerate(items):
            col=j%cols;row=j//cols;cell=ttk.Frame(frame,padding=(0,4,18,8));cell.grid(row=row,column=col,sticky='ew');frame.columnconfigure(col,weight=1)
            ttk.Label(cell,text=label,wraplength=365).pack(anchor='w');v=tk.StringVar(value=str(value));ttk.Entry(cell,textvariable=v).pack(fill='x',pady=4);out[key]=v
        return out
    def table(self,columns,rows,parent=None,height=7):
        frame=ttk.Frame(parent or self.body);frame.pack(fill='both',expand=True,pady=8);tree=ttk.Treeview(frame,columns=[str(i) for i in range(len(columns))],show='headings',height=height)
        sy=ttk.Scrollbar(frame,orient='vertical',command=tree.yview);sx=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview);tree.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        sy.pack(side='right',fill='y');sx.pack(side='bottom',fill='x');tree.pack(fill='both',expand=True)
        for i,label in enumerate(columns):tree.heading(str(i),text=label);tree.column(str(i),width=max(115,min(310,len(label)*8)),minwidth=90)
        for row in rows:tree.insert('','end',values=row)
        return tree
    def chart(self,series,labels,parent=None):
        ca=tk.Canvas(parent or self.body,height=250,bg=WHITE,highlightthickness=1,highlightbackground='#D9E6F1');ca.pack(fill='x',pady=12)
        def draw(ev=None):
            if not ca.winfo_exists():return
            ca.delete('all');w=max(ca.winfo_width(),400);h=250;left=75;right=w-25;top=42;bot=205
            vals=[v for ar in series.values() for v in ar if v is not None];lo=min([0]+vals);hi=max([1]+vals);span=hi-lo or 1
            y=lambda v:bot-(v-lo)/span*(bot-top)
            for t in range(5):
                v=lo+span*t/4;yy=y(v);ca.create_line(left,yy,right,yy,fill='#E8EFF5');ca.create_text(left-8,yy,text=fmt(v,0),anchor='e',font=(FONT,8),fill=INK)
            for k,(name,ar) in enumerate(series.items()):
                color=[BLUE,'#BD9140','#315F87'][k%3];ca.create_line(left+k*220,18,left+25+k*220,18,fill=color,width=3);ca.create_text(left+32+k*220,18,text=name,anchor='w',fill=INK,font=(FONT,9))
                pts=[]
                for i,v in enumerate(ar):
                    if v is not None:pts.extend((left+i*(right-left)/max(1,len(ar)-1),y(v)))
                if len(pts)>=4:ca.create_line(*pts,fill=color,width=3)
                elif len(pts)==2:ca.create_oval(pts[0]-3,pts[1]-3,pts[0]+3,pts[1]+3,fill=color,outline=color)
            step=max(1,math.ceil(len(labels)/8))
            for i,label in enumerate(labels):
                if i%step==0 or i==len(labels)-1:ca.create_text(left+i*(right-left)/max(1,len(labels)-1),228,text=label,fill=INK,font=(FONT,8))
        ca.bind('<Configure>',draw);self.after_idle(draw);return ca
    def save_now(self):
        if self.commit:self.commit()
        self.pid=self.store.save(self.user['id'],self.project,self.pid);self.status.set('Proyecto guardado · '+self.project['nombre'])
    def page_inicio(self):
        self.heading('Bienvenido a MTH-A',f"Hola, {self.user['name']}. Organizá tu operación y compará formas de producir.")
        banner=tk.Frame(self.body,bg=WHITE,padx=24,pady=18);banner.pack(fill='x');self.sun(banner,90).pack(side='right')
        tk.Label(banner,text=self.project['nombre'],bg=WHITE,fg=NAVY,font=(FONT,18,'bold')).pack(anchor='w');tk.Label(banner,text=f"{self.project['familia']}\n{self.project['meses']} meses · {self.project['inicio']} · {self.project['moneda']}",bg=WHITE,fg=INK,font=(FONT,11),justify='left').pack(anchor='w',pady=10)
        self.note('Un proyecto conecta demanda, existencias, producción y economía. Los valores iniciales son una demostración editable.')
        for title,text,dest in [('01  Demanda','Definí el volumen mensual y explorá posibles pedidos.','demanda'),('02  Inventario y capacidad','Ingresá existencias, tiempos y disponibilidad productiva.','inventario'),('03  Simulación','Elegí los grupos MTS/MTO y observá el recorrido de los pedidos.','simulacion'),('04  Economía','Valorá la misma operación y compará costos y fondos.','economia')]:
            box=ttk.Frame(self.body,padding=14);box.pack(fill='x',pady=5);ttk.Label(box,text=title,font=(FONT,13,'bold')).pack(anchor='w');ttk.Label(box,text=text).pack(side='left',pady=6);ttk.Button(box,text='Abrir',command=lambda d=dest:self.nav(d)).pack(side='right')
    def page_proyecto(self):
        self.heading('Mi proyecto','Guardá escenarios distintos para cada familia u operación. Cada proyecto usa un recurso productivo agregado.')
        entries=self.fields([('nombre','Nombre del proyecto',self.project['nombre']),('familia','Familia / producto',self.project['familia']),('inicio','Mes inicial (AAAA-MM)',self.project['inicio']),('meses','Meses a simular (1 a 24)',self.project['meses']),('moneda','Moneda de presentación',self.project['moneda']),('base','Base de precios constantes',self.project['base'])])
        def commit():
            p=copy.deepcopy(self.project)
            for k,v in entries.items():p[k]=v.get().strip()
            if not p['nombre'] or not p['familia'] or not p['moneda']:raise ValueError('Completá nombre, familia y moneda.')
            p['meses']=number(p['meses'],'Meses',1,24,True);ms=months(p['inicio'],p['meses']);old=self.project['operacion']['demanda_mensual']
            p['operacion']['demanda_mensual']=[{'mes':m,'m2':old[i]['m2'] if i<len(old) else old[-1]['m2']} for i,m in enumerate(ms)]
            self.project=prepare(p)
        self.commit=commit;self.buttons([('Guardar proyecto',self.save_now),('Crear proyecto nuevo',self.new),('Exportar proyecto',self.export_project),('Importar proyecto MTH-A',self.import_project)])
        self.note('Al extender el horizonte se repite como punto de partida el último volumen mensual: revisalo en Demanda. Cambiar la etiqueta de moneda no convierte importes; costos y precios deben usar la misma unidad.')
        ps=self.store.projects(self.user['id']);tree=self.table(['ID','Proyecto','Última edición'],[(x['id'],x['name'],x['updated']) for x in ps])
        def load():
            if not tree.selection():raise ValueError('Seleccioná un proyecto.')
            self.load_project(int(tree.item(tree.selection()[0],'values')[0]))
        self.buttons([('Abrir proyecto seleccionado',load)])
    def new(self):
        if self.proc:raise ValueError('Esperá o cancelá la ejecución antes de cambiar de proyecto.')
        self.save_now();self.project=new_project();self.project['nombre']='Nueva operación';self.pid=self.store.save(self.user['id'],self.project);self.result=None;self.folder=None;self.commit=None;self.nav('proyecto',False)
    def load_project(self,pid):
        if self.proc:raise ValueError('Esperá o cancelá la ejecución antes de cambiar de proyecto.')
        self.save_now();self.project=self.store.load(self.user['id'],pid);self.pid=pid;self.result=None;self.folder=None;self.commit=None;self.nav('inicio',False)
    def export_project(self):
        self.save_now();path=filedialog.asksaveasfilename(defaultextension='.json',initialfile='Proyecto_MTHA.json',filetypes=[('Proyecto MTH-A','*.json')])
        if path:Path(path).write_text(json.dumps(self.project,ensure_ascii=False,indent=2),encoding='utf-8')
    def import_project(self):
        if self.proc:raise ValueError('Hay una ejecución en curso.')
        path=filedialog.askopenfilename(filetypes=[('Proyecto MTH-A','*.json')])
        if not path:return
        p=prepare(json.loads(Path(path).read_text(encoding='utf-8-sig')));self.save_now();self.project=p;self.pid=self.store.save(self.user['id'],p);self.commit=None;self.result=None;self.folder=None;self.nav('inicio',False)
    def page_demanda(self):
        self.heading('Demanda','La serie mensual alimenta tanto la simulación operativa como el análisis económico.')
        p=self.project;pr=p['operacion']['parametros'];self.note('Cargá directamente los m² por mes o construí una estimación desde el mercado. La cuota de mercado se aplica sólo al usar el botón de estimación.')
        vals=self.fields([(k,label,p['mercado'][k]) for k,label in [('mensual','Mercado mensual total (m²)'),('zona','Participación de la zona (%)'),('cuota','Cuota de la empresa (%)'),('familia','Participación de la familia (%)')]])
        series=self.fields([(str(i),m['mes']+' · demanda (m²)',m['m2']) for i,m in enumerate(p['operacion']['demanda_mensual'])],cols=3)
        order=self.fields([('mean','Pedido medio (m²)',pr['order_mean']),('sd','Desvío del pedido (m²)',pr['order_sd']),('seed','Semilla',p['semilla']),('n','Réplicas (1 a 100)',p['replicas'])])
        def commit():
            q=copy.deepcopy(self.project)
            for k,v in vals.items():q['mercado'][k]=number(v.get(),k,0,1e12 if k=='mensual' else 100)
            for i,v in series.items():q['operacion']['demanda_mensual'][int(i)]['m2']=number(v.get(),'Demanda',0,1e7)
            q['operacion']['parametros']['order_mean']=number(order['mean'].get(),'Pedido medio',1,1e7);q['operacion']['parametros']['order_sd']=number(order['sd'].get(),'Desvío',0,1e7)
            q['semilla']=number(order['seed'].get(),'Semilla',0,4294967295,True);q['replicas']=number(order['n'].get(),'Réplicas',1,100,True);self.project=prepare(q)
        self.commit=commit
        def estimate():
            commit();m=self.project['mercado'];base=m['mensual']*m['zona']/100*m['cuota']/100*m['familia']/100
            for v in series.values():v.set(str(round(base,4)))
            self.status.set('Estimación constante aplicada. Ajustá las variaciones de cada mes antes de simular.')
        self.buttons([('Guardar demanda',self.save_now),('Estimar todos los meses',estimate),('Simular pedidos',lambda:self.start('demanda'))])
        self.note('El número de pedidos sigue una distribución Poisson y su tamaño una lognormal. Las fechas se distribuyen dentro del mes. La misma semilla y configuración reproducen los pedidos; las políticas comparten cada realización.')
        if self.result and self.result['tipo']=='demanda':
            r=self.result;self.chart({'Objetivo':[x['objetivo'] for x in r['mensual']],'Media simulada':[x['media'] for x in r['mensual']]},[x['mes'] for x in r['mensual']])
            self.table(['Mes','Objetivo m²','Media simulada','Percentil 2,5 %','Percentil 97,5 %'],[(x['mes'],fmt(x['objetivo']),fmt(x['media']),fmt(x['p025']),fmt(x['p975'])) for x in r['mensual']])
            self.note(f"Resultados de la ejecución guardada: {r['replicas']} réplicas. Los percentiles describen variación de demanda; no son el intervalo de confianza de la media. Con pocas réplicas son sólo exploratorios.")
            self.buttons([('Exportar ejecución',self.export_run)])
    def page_inventario(self):
        self.heading('Inventario y capacidad','Las existencias iniciales se distribuyen entre los grupos según su participación. No se confunden materia prima, proceso y producto terminado.')
        c=self.project['operacion'];pr=c['parametros'];m=c['materiales']
        keys=[('initial_fg','Producto terminado inicial (m²)'),('initial_wip','Producto en proceso inicial (m² netos)'),('initial_backlog','Pedidos pendientes iniciales (m²)'),('lot','Lote neto vendible (m²)'),('net_rate','Ritmo neto (m²/h)'),('quality_hours','Control de calidad (horas)'),('transport_hours','Transporte (horas)'),('planning_lead_days','Horizonte de reposición (días)'),('forecast_smoothing','Suavizado de previsión (0 a 1)')]
        a=self.fields([(k,label,pr[k]) for k,label in keys]+[('width','Horas por ventana · 3 ventanas/mes',c['ventanas'][0][1])])
        ttk.Label(self.body,text='Abastecimiento',font=(FONT,15,'bold')).pack(anchor='w',pady=10)
        b=self.fields([(k,label,m[k]) for k,label in [('cobertura_inicial_dias','Cobertura inicial de materia prima (días)'),('plazo_dias','Plazo de proveedor (días)'),('punto_pedido_dias','Punto de pedido (días)'),('objetivo_dias','Objetivo de compra (días)'),('cuerpo_kg_lote','Cuerpo cerámico por lote (kg)'),('esmalte_kg_lote','Esmalte por lote (kg)')]])
        def commit():
            q=copy.deepcopy(self.project)
            for k,v in a.items():
                if k=='width':q['operacion']['ventanas']=[[0,number(v.get(),'Ventana',.1,192)]]
                else:q['operacion']['parametros'][k]=number(v.get(),k)
            for k,v in b.items():q['operacion']['materiales'][k]=number(v.get(),k)
            self.project=prepare(q)
        self.commit=commit
        def balance():
            self.save_now();c=self.project['operacion'];pr=c['parametros'];m=c['materiales'];mp=pr['monthly_demand']/pr['days']*m['cobertura_inicial_dias']/pr['lot'];kg=mp*(m['cuerpo_kg_lote']+m['esmalte_kg_lote']);cap=3*c['ventanas'][0][1]*pr['net_rate']
            messagebox.showinfo('Disponibilidad inicial',f'Materia prima: {fmt(mp)} recetas equivalentes\nMasa de materia prima: {fmt(kg)} kg\nCapacidad neta nominal asignada: {fmt(cap)} m²/mes\n\nLa capacidad realizable depende de ventanas, lotes completos, materiales y tiempos. No es una promesa de entrega.',parent=self)
        self.buttons([('Guardar inventario',self.save_now),('Calcular disponibilidad',balance)])
        self.note('Las ventanas empiezan a las horas 0, 240 y 480 de cada mes. El resto del tiempo representa capacidad no asignada a esta familia. Un lote debe caber entero en una ventana. El costo de la receta se configura aparte en Economía: si cambiás su composición, revisá también ese costo.')
    def page_simulacion(self):
        self.heading('Simulación de la operación','Compará fabricación para existencias (MTS) con una combinación de MTS y fabricación bajo pedido (MTO).')
        frame=ttk.Frame(self.body);frame.pack(fill='x');group_vars={};checks={}
        for j,label in enumerate(['Grupo','Participación (%)','Plazo cliente (días)','Fabricar para stock']):ttk.Label(frame,text=label,font=(FONT,10,'bold')).grid(row=0,column=j,padx=8,pady=8)
        for i,g in enumerate(self.project['operacion']['grupos'],1):
            ttk.Label(frame,text=g['id']+' · '+g['name'],wraplength=240).grid(row=i,column=0,sticky='w',padx=8,pady=8)
            v=tk.StringVar(value=str(g['share']*100));d=tk.StringVar(value=str(g['deadline_days']));ck=tk.BooleanVar(value=g['id'] in self.project['grupos_mts']);group_vars[g['id']]=(v,d);checks[g['id']]=ck
            ttk.Entry(frame,textvariable=v,width=12).grid(row=i,column=1,padx=8);ttk.Entry(frame,textvariable=d,width=12).grid(row=i,column=2,padx=8);ttk.Checkbutton(frame,variable=ck).grid(row=i,column=3)
        self.note('Marcado = MTS; sin marcar = MTO. H70 significa que los grupos marcados suman 70 % de la demanda esperada. No obliga a producir exactamente 70 % de los lotes para stock.')
        entries=self.fields([('n','Réplicas',self.project['replicas']),('seed','Semilla',self.project['semilla'])])
        def commit():
            q=copy.deepcopy(self.project)
            for g in q['operacion']['grupos']:
                v,d=group_vars[g['id']];g['share']=number(v.get(),'Participación',0,100)/100;g['deadline_days']=number(d.get(),'Plazo',0,90)
            q['grupos_mts']=[k for k,v in checks.items() if v.get()];q['replicas']=number(entries['n'].get(),'Réplicas',1,100,True);q['semilla']=number(entries['seed'].get(),'Semilla',0,4294967295,True);self.project=prepare(q)
        self.commit=commit
        self.buttons([('Simular y comparar',lambda:self.start('comparacion')),('Cancelar ejecución',self.cancel),('Exportar resultados',self.export_run)])
        if self.result and self.result['tipo']=='comparacion':
            r=self.result;h=r['politica'];self.note(f"Ejecución guardada: {r['replicas']} pares · semilla {r['semilla']}. Si cambiás entradas, volvé a ejecutar para actualizarlos.")
            keys=[('Inventario terminado promedio (m²)','fg_promedio_m2'),('OTIF (%)','otif_pct'),('Plazo medio entregados (días)','lead_dias'),('Pedidos pendientes (m²)','pendiente_total_m2'),('Utilización (%)','utilizacion_pct')]
            self.table(['Indicador','MTS100',h],[(label,fmt(r['medias']['MTS100'].get(k)),fmt(r['medias'][h].get(k))) for label,k in keys],height=5)
            self.chart(r['series'],r['meses']);self.note('OTIF: pedidos nuevos cuyo vencimiento está dentro del horizonte operativo. El plazo medio sólo incluye los entregados al corte. Los pendientes siguen identificados durante 30 días adicionales.')
            self.replay(r)
    def replay(self,r):
        ttk.Label(self.body,text='Recorrido de la primera réplica',font=(FONT,15,'bold')).pack(anchor='w',pady=15)
        line=ttk.Frame(self.body);line.pack(fill='x');choice=tk.StringVar(value=r['politica']);combo=ttk.Combobox(line,textvariable=choice,values=list(r['medias']),state='readonly',width=15);combo.pack(side='left')
        status=tk.StringVar(value='');ttk.Label(line,textvariable=status).pack(side='left',padx=12)
        ca=tk.Canvas(self.body,bg=WHITE,height=180,highlightthickness=1,highlightbackground='#D9E6F1');ca.pack(fill='x',pady=10)
        eventtext=tk.StringVar();ttk.Label(self.body,textvariable=eventtext,wraplength=800).pack(anchor='w')
        detail={};events=[];slider=ttk.Scale(self.body,from_=0,to=1);slider.pack(fill='x',pady=8)
        def display(_=None):
            if not events:return
            i=min(len(events)-1,int(slider.get()));ev=events[i];ca.delete('all');w=max(800,ca.winfo_width());step=w/4
            labels=[('Materia prima',fmt(ev['mp_lotes'])+' recetas'),('En proceso',fmt(ev['wip_m2'])+' m²'),('Terminado',fmt(ev['fg_m2'])+' m²'),('Pendientes',fmt(ev['pendiente_m2'])+' m²')]
            for j,(name,val) in enumerate(labels):
                x=12+j*step;ca.create_rectangle(x,45,x+step-24,135,fill='#EBF5FE',outline=BLUE,width=2);ca.create_text(x+(step-24)/2,70,text=name,font=(FONT,11,'bold'),fill=NAVY);ca.create_text(x+(step-24)/2,105,text=val,font=(FONT,11),fill=INK)
            stamp=datetime.fromisoformat(self.snapshot['operacion']['inicio'])+timedelta(hours=ev['hora'])
            status.set(f'{stamp:%d/%m/%Y %H:%M} · evento {i+1} de {len(events)}')
            eventtext.set(f"{ev['evento'].replace('_',' ').capitalize()} · {ev['grupo']} · {fmt(ev['cantidad_m2'])} m² · Pedido {ev['pedido'] or '—'} · Lote {ev['lote'] or '—'}")
        def load(_=None):
            nonlocal detail,events
            self.playing=False;path=self.folder/f'detalle_{choice.get()}.json';detail=json.loads(path.read_text(encoding='utf-8'));events=detail['eventos'];slider.configure(to=max(1,len(events)-1));slider.set(0);display()
        slider.configure(command=display);combo.bind('<<ComboboxSelected>>',load);ca.bind('<Configure>',display)
        def tick():
            if not self.playing or not slider.winfo_exists():return
            at=min(len(events)-1,int(slider.get())+max(1,len(events)//220));slider.set(at);display()
            if at==len(events)-1:self.playing=False
            else:self.after(180,tick)
        def play():
            self.playing=not self.playing
            if self.playing:
                if slider.get()>=len(events)-1:slider.set(0)
                tick()
        self.buttons([('Reproducir / pausar',play),('Ver pedidos',lambda:self.show_orders(detail))]);load()
    def show_orders(self,detail):
        win=tk.Toplevel(self);win.title('Pedidos de la primera réplica');win.geometry('980x550')
        ttk.Label(win,text='Horas desde el comienzo de la operación. “Pendiente” indica que no se entregó durante el seguimiento.',padding=15,wraplength=900).pack(anchor='w')
        self.table(['Pedido','Grupo','Cantidad m²','Ingreso h','Vencimiento h','Entrega h'],[(o['id'],o['group'],fmt(o['qty']),fmt(o['arrival']),fmt(o['due']),fmt(o.get('delivery')) if o.get('delivery') is not None else 'Pendiente') for o in detail['pedidos_seguimiento']],win,14)
    def page_economia(self):
        self.heading('Economía','Los costos se aplican a las actividades y entregas de la misma simulación. Moneda: '+self.project['moneda']+' · '+self.project['base'])
        tabs=ttk.Notebook(self.body);tabs.pack(fill='x',pady=10);pages=[]
        for name in ['Precio y caja','Implementación','Costos de operación']:
            f=ttk.Frame(tabs,padding=12);tabs.add(f,text=name);pages.append(f)
        p=self.project;e=p['economia'];pr=p['precios'];co=p['costos']
        specs=[('price','Precio por m² (sin IVA)',1),('fx','Tipo de cambio · moneda por USD',1),('ret','Descuentos / devoluciones (%)',100),('iibb','Tributo sobre ventas (%)',100),('municipal','Tributo municipal (%)',100),('comm','Comisión (%)',100),('freight','Flete (USD/m²)',1),('handle','Manipulación (USD/m²)',1),('reverse','Logística inversa (USD/m² devuelto)',1),('bank','Tributo bancario parcial (%)',100)]
        a=self.fields([(k,label,pr[k]*factor) for k,label,factor in specs],pages[0])
        es=[('real_rate','Tasa real anual (%)',100),('residual_fraction','Recuperación de inventario al cierre (%)',100),('dso_days','Plazo de cobro (días, máximo 60)',1),('dpo_days','Plazo de pago (días, máximo 60)',1),('implementation_services','Servicios iniciales',1),('implementation_assets','Equipos iniciales',1),('contingency_fraction','Contingencia inicial (%)',100),('support_monthly','Soporte adicional mensual',1),('holding_monthly','Tenencia adicional mensual (%)',100),('material_factor','Factor costo materiales (1 = base)',1),('energy_factor','Factor costo energía (1 = base)',1)]
        b=self.fields([(k,label,e[k]*factor) for k,label,factor in es],pages[1])
        cs=[('matlot_usd','Materia prima por receta (USD)',1),('pack_usd','Embalaje (USD/m²)',1),('elec_m2','Electricidad por m² · referencia lote 900',1),('gas_mj','Energía térmica MJ/m² · referencia lote 900',1),('gas_usd','Gas (USD/MMBtu)',1),('maintenance_usd_h','Mantenimiento esperado (USD/h)',1),('water_lot','Agua / tratamiento por lote',1),('labor_factory','Personal fabril mensual',1),('admin','Administración mensual',1),('fixed_energy','Energía fija mensual',1),('depreciation','Depreciación mensual',1),('store','Depósito mensual',1),('idle_fraction','Consumo en espera (% del activo)',100),('startup_mj','Energía por arranque (MJ)',1),('vat','IVA general supuesto (%)',100),('vat_energy','IVA energía supuesto (%)',100)]
        d=self.fields([(k,label,co[k]*factor) for k,label,factor in cs],pages[2])
        def commit():
            q=copy.deepcopy(self.project)
            for defs,vs,key in [(specs,a,'precios'),(es,b,'economia'),(cs,d,'costos')]:
                for k,label,mult in defs:q[key][k]=number(vs[k].get(),label)/mult
            self.project=prepare(q)
        self.commit=commit
        actions=self.buttons([('Guardar y evaluar',lambda:self.start('comparacion')),('Guardar valores',self.save_now),('Cancelar',self.cancel),('Exportar resultados',self.export_run)]);actions.pack(before=tabs)
        self.note('Los importes son supuestos editables; el sistema no consulta tarifas ni liquida impuestos oficiales. El VAN principal es anterior a Ganancias. El valor remanente no se registra como cobro real. Los costos fijos se mantienen aunque varíe la producción.')
        if self.result and self.result['tipo']=='comparacion':
            r=self.result;h=r['politica'];self.note('Resultados de la ejecución guardada. Si editaste valores, volvé a evaluar para actualizarlos.');self.table(['Indicador incremental · '+h+' menos MTS','Valor'],[('VAN · '+self.snapshot['moneda'],fmt(r['van']['media'])),('IC 95 % del VAN',fmt(r['van']['inferior'])+' a '+fmt(r['van']['superior']) if r['replicas']>1 else 'No estimable con una réplica'),('ROI sin descuento (%)',fmt(r['roi'])),('Réplicas',r['replicas'])],height=4)
            self.chart({'Flujo incremental valorado':r['flujo']},[str(i) for i in range(len(r['flujo']))]);self.note('Período 0: implementación. Último período: incluye inventario remanente. El ROI suma el flujo sin descuento y lo divide por el desembolso inicial. Si éste es cero, el ROI no se define. Un VAN positivo no reemplaza la evaluación del servicio.')
            self.table(['Indicador del período','MTS100',h],[(label,fmt(r['medias']['MTS100'].get(k)),fmt(r['medias'][h].get(k))) for label,k in [('Costo industrial','costo_industrial_10m'),('Resultado operativo','resultado_operativo_10m'),('Capital de trabajo al cierre operativo','nct_diciembre')]],height=3)
    def start(self,kind):
        if self.proc:raise ValueError('Ya hay una ejecución en curso.')
        self.save_now();p=prepare(self.project);self.folder=DATA/'ejecuciones'/str(self.user['id'])/datetime.now().strftime('%Y%m%d_%H%M%S_%f');self.folder.mkdir(parents=True)
        self.snapshot=copy.deepcopy(p);self.run_owner=(self.user['id'],self.pid,p['nombre'],kind);self.result=None
        (self.folder/'proyecto.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
        (self.folder/'usuario.json').write_text(json.dumps({'nombre':self.user['name'],'empresa':self.user['company'],'usuario':self.user['username']},ensure_ascii=False,indent=2),encoding='utf-8')
        self.log=(self.folder/'ejecucion.log').open('w',encoding='utf-8');self.proc=subprocess.Popen([sys.executable,str(ROOT/'tareas.py'),str(self.folder),kind],stdout=self.log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),cwd=ROOT)
        self.status.set('Calculando… los resultados aparecerán al terminar. Podés recorrer las secciones.');self.progress.configure(maximum=p['replicas'],value=0)
    def poll(self):
        if self.proc:
            advance=self.folder/'avance.json'
            try:
                if advance.exists():a=json.loads(advance.read_text(encoding='utf-8'));self.progress.configure(value=a['avance']);self.status.set(f"Calculando · {a['avance']} de {a['total']} réplicas completas")
            except (OSError,ValueError):pass
            code=self.proc.poll()
            if code is not None:
                self.proc=None;self.log.close()
                if code==0 and (self.folder/'resumen.json').exists():
                    self.result=json.loads((self.folder/'resumen.json').read_text(encoding='utf-8'));uid,pid,name,kind=self.run_owner;self.store.add_run(uid,pid,name,self.folder,kind);self.status.set('Ejecución terminada y guardada en tu historial.')
                    dest='demanda' if kind=='demanda' else ('economia' if self.last_page=='economia' else 'simulacion');self.nav(dest)
                else:
                    error=self.folder/'error.json';msg=json.loads(error.read_text(encoding='utf-8'))['error'] if error.exists() else 'Revisá el registro de ejecución.';self.status.set('La ejecución no se completó.');messagebox.showerror('Ejecución incompleta',msg+'\nPodés exportar esta ejecución para revisar el diagnóstico.',parent=self)
        self.after(400,self.poll)
    def cancel(self):
        if self.proc:
            self.proc.terminate();self.proc.wait(timeout=10);self.proc=None;self.log.close();self.result=None;self.status.set('Ejecución cancelada. Tus parámetros permanecen guardados.')
    def export_run(self):
        if self.proc:raise ValueError('Esperá o cancelá antes de exportar.')
        if not self.folder or not self.folder.exists():raise ValueError('Primero ejecutá una simulación o seleccioná una en el historial.')
        path=filedialog.asksaveasfilename(defaultextension='.zip',initialfile='MTHA_Resultados.zip',filetypes=[('Resultados MTH-A','*.zip')])
        if path:
            with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
                for f in self.folder.iterdir():
                    if f.is_file():z.write(f,f.name)
            self.status.set('Resultados exportados.')
    def page_historial(self):
        self.heading('Historial','Cada ejecución guarda el usuario, las entradas utilizadas y sus resultados. Los cambios posteriores no alteran corridas anteriores.')
        runs=self.store.runs(self.user['id']);tree=self.table(['ID','Proyecto','Tipo','Fecha'],[(r['id'],r['name'],r['kind'],r['created']) for r in runs],height=15)
        def selected():
            if self.proc:raise ValueError('Esperá que termine la ejecución actual.')
            if not tree.selection():raise ValueError('Seleccioná una ejecución.')
            rid=int(tree.item(tree.selection()[0],'values')[0]);return next(r for r in runs if r['id']==rid)
        def view():
            r=selected();self.save_now();self.folder=Path(r['folder']);self.snapshot=json.loads((self.folder/'proyecto.json').read_text(encoding='utf-8'));self.result=json.loads((self.folder/'resumen.json').read_text(encoding='utf-8'))
            # Reopen the actual snapshot as an independent project, so displayed inputs match.
            self.project=copy.deepcopy(self.snapshot);self.project['nombre']+=' · copia del historial';self.pid=self.store.save(self.user['id'],self.project);self.commit=None;self.nav('demanda' if r['kind']=='demanda' else 'simulacion',False)
        def export():
            r=selected();self.folder=Path(r['folder']);self.export_run()
        self.buttons([('Abrir como proyecto nuevo',view),('Exportar selección',export)])
    def page_datos(self):
        self.heading('Importar y analizar datos','Conservá el diagnóstico por familias de tus planillas anteriores y llevá su demanda al proyecto activo.')
        self.note('Podés importar el proyecto JSON del módulo de datos anterior, o una carpeta con FAMILIAS.csv, DEMANDA.csv, INVENTARIO.csv y PARAMETROS_MTHA.csv. El cálculo incluye normalización de parámetros, faltantes y trazabilidad.')
        controls=ttk.Frame(self.body);controls.pack(fill='x');panel=ttk.Frame(self.body);panel.pack(fill='both',expand=True)
        self.legacy=None
        def analyze(payload):
            from mtha.analisis import analyze as calc
            report=calc(payload);self.legacy=(payload,report)
            for w in panel.winfo_children():w.destroy()
            ttk.Label(panel,text='Diagnóstico por familias',font=(FONT,14,'bold')).pack(anchor='w',pady=10)
            for row in report['resultados']:
                ttk.Label(panel,text=str(row.get('familia_id','Familia')),font=(FONT,11,'bold')).pack(anchor='w')
                self.table(['Indicador','Valor'],[(k.replace('_',' '),fmt(v) if isinstance(v,(int,float)) else str(v)) for k,v in row.items() if not isinstance(v,(dict,list))],panel,6)
            self.note(f"Datos faltantes detectados: {len(report['faltantes'])}. El diagnóstico determinista no sustituye la simulación de pedidos.",panel)
            if report['avisos']:self.note('\n'.join(str(a) for a in report['avisos']),panel)
            from mtha.analisis import read_csv
            families=read_csv(payload['tables']['FAMILIAS'],'FAMILIAS');sel=tk.StringVar(value=families[0]['familia_id']);ttk.Combobox(panel,textvariable=sel,values=[f['familia_id'] for f in families],state='readonly').pack(anchor='w',pady=8)
            def apply():
                if self.proc:raise ValueError('Esperá que termine la ejecución.')
                fid=sel.get();dem=read_csv(payload['tables']['DEMANDA'],'DEMANDA');inv=read_csv(payload['tables']['INVENTARIO'],'INVENTARIO');period=months(payload['inicio'],24)
                from mtha.analisis import months_between
                period=months_between(payload['inicio'],payload['fin'])
                if len(period)>24:raise ValueError('La simulación admite hasta 24 meses.')
                chosen={r['mes']:r for r in dem if r['familia_id']==fid}
                if any(m not in chosen or chosen[m]['demanda_m2']=='' for m in period):raise ValueError('Completá todos los meses de demanda de esta familia antes de transferir.')
                initial=next((r for r in inv if r['familia_id']==fid and r['mes']==period[0]),None)
                if not initial or initial['stock_inicio_m2']=='':raise ValueError('Falta el stock inicial del primer mes.')
                if not messagebox.askyesno('Aplicar datos','Se reemplazarán la familia, el horizonte, la demanda y el terminado inicial. Revisá después capacidad, proceso, pendientes y costos: no se transfieren automáticamente.',parent=self):return
                q=copy.deepcopy(self.project);q['familia']=next(f['nombre'] for f in families if f['familia_id']==fid);q['inicio']=period[0];q['meses']=len(period);q['operacion']['demanda_mensual']=[{'mes':m,'m2':number(chosen[m]['demanda_m2'],'Demanda')} for m in period];q['operacion']['parametros']['initial_fg']=number(initial['stock_inicio_m2'],'Inventario inicial');q['notas']='Demanda e inventario importados de proyecto de datos; revisar restantes supuestos.';self.project=prepare(q);self.save_now();self.nav('demanda',False)
            def export():
                path=filedialog.asksaveasfilename(defaultextension='.json',initialfile='Diagnostico_MTHA.json')
                if path:Path(path).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
            self.buttons([('Aplicar familia al proyecto',apply),('Exportar diagnóstico completo',export)],panel)
        def loadjson():
            path=filedialog.askopenfilename(filetypes=[('Proyecto de datos anterior','*.json')])
            if path:analyze(json.loads(Path(path).read_text(encoding='utf-8-sig')))
        def loadcsv():
            path=filedialog.askdirectory()
            if not path:return
            from mtha.analisis import read_csv
            tables={k:(Path(path)/(k+'.csv')).read_text(encoding='utf-8-sig') for k in ['FAMILIAS','DEMANDA','INVENTARIO','PARAMETROS_MTHA']};dem=read_csv(tables['DEMANDA'],'DEMANDA');period=sorted(r['mes'] for r in dem)
            if not period:raise ValueError('La tabla de demanda está vacía.')
            analyze({'version_proyecto':1,'inicio':period[0],'fin':period[-1],'tables':tables})
        self.buttons([('Abrir proyecto de datos anterior',loadjson),('Abrir carpeta de CSV',loadcsv)],controls)
    def page_ayuda(self):
        self.heading('Cómo trabajar con MTH-A','Una aplicación local para explorar decisiones industriales.')
        for title,text in [
          ('1. Preparar el proyecto','Ingresá una familia y el horizonte. Los proyectos se guardan al cambiar de sección o al presionar Guardar. Cada usuario ve sus propios proyectos e historial.'),
          ('2. Definir la demanda','Cargá los m² mensuales. Si partís de mercado total, aplicá zona × cuota × familia una sola vez. Ajustá pedido medio y desvío; después explorá los pedidos posibles.'),
          ('3. Cargar existencias y capacidad','Separá terminado, proceso y pendientes. La materia prima inicial se calcula con días de cobertura sobre la demanda inicial. El ritmo ya es neto y no vuelve a descontar pérdidas de disponibilidad.'),
          ('4. Elegir la política','Marcá qué grupos fabricar para stock. Los demás se liberan contra pedido. MTS100 sirve de comparación. Las participaciones deben sumar 100 %. No es un optimizador: vos proponés las políticas y evaluás sus consecuencias.'),
          ('5. Simular y observar','Empezá con tres réplicas. Reproducí los eventos de la primera para ver existencias, proceso y pendientes. El gráfico mensual resume todas las réplicas. Aumentá las repeticiones cuando necesites mayor precisión.'),
          ('6. Evaluar la economía','Completá precio, costos, plazos y presupuesto de implementación en una misma moneda constante. Evaluar vuelve a ejecutar la operación con esas entradas. Las réplicas de ambas políticas usan los mismos pedidos.'),
          ('7. Guardar y compartir','El historial conserva la configuración ejecutada. Exportar resultados crea un ZIP con tablas CSV y parámetros. Abrir una corrida del historial crea un proyecto nuevo con sus entradas; no cambia el original.'),
          ('Qué representa la cuenta','Es un registro local de uso, sin verificación de identidad ni correo. La contraseña se guarda con derivación PBKDF2 y sal, no como texto. La base local no está cifrada: usá los permisos de tu computadora para resguardar sus archivos. No hay recuperación por correo.'),
          ('Alcance de esta versión','Se simula una familia con cuatro grupos y un recurso agregado por proyecto. Otras familias se representan por el tiempo no asignado. No coordina automáticamente varias plantas ni sustituye un ERP contable. El horizonte operativo admite entre 1 y 24 meses, con 30 días de seguimiento y al menos tres meses para cierre de cobros y pagos.'),
          ('Balances y costos','La receta física y su costo monetario se editan por separado. Cambiar masa no busca precios de materias primas. La electricidad y el gas por m² conservan la referencia de un lote de 900 m²: cambiar el lote neto representa un cambio de rendimiento, por lo que se redistribuye el consumo del lote. El trabajo en proceso inicial conserva un 40 % de trabajo pendiente.'),
          ('Leer el resultado con cuidado','OTIF y plazo usan poblaciones distintas; mirá también los pendientes. VAN y ROI pueden tener signos distintos por el momento de los flujos. El valor remanente final es una valoración, no un cobro simulado. Los impuestos son provisiones configurables y el tributo bancario sólo incluye los movimientos modelados.'),
          ('Datos y copias','Los datos se conservan en '+str(DATA)+'. Para una copia integral, cerrá la aplicación y copiá esa carpeta. No compartas su base de usuarios si sólo necesitás enviar resultados.')]:
            ttk.Label(self.body,text=title,font=(FONT,13,'bold')).pack(anchor='w',pady=(16,3));self.note(text)
    def logout(self):
        if self.proc:raise ValueError('Esperá o cancelá antes de cerrar sesión.')
        self.save_now();self.playing=False;self.user=None;self.login_page()
    def close(self):
        if self.proc:
            if not messagebox.askyesno('Cerrar MTH-A','Hay una ejecución en curso. ¿Querés cancelarla y cerrar?',parent=self):return
            self.cancel()
        try:
            if self.user:self.save_now()
        except Exception as ex:
            if not messagebox.askyesno('Cambios sin guardar',str(ex)+'\n¿Cerrar sin guardar esos cambios?',parent=self):return
        self.destroy()

if __name__=='__main__':
    try:App().mainloop()
    except Exception:
        import traceback
        DATA.mkdir(parents=True,exist_ok=True);(DATA/'error_inicio.txt').write_text(traceback.format_exc(),encoding='utf-8')
        raise
