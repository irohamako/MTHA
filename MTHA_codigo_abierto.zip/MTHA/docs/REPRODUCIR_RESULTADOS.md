# Reproducir los resultados de la tesis

1. Instalar las dependencias fijadas: `pip install -r ../aplicacion_escritorio/requirements.txt`.
2. Abrir `sistema_web` (`python sistema.py`) o la aplicación de escritorio.
3. Conservar los valores originales de `motor/configuracion_operativa.json` y `motor/parametros_economicos_previos.json`.
4. Elegir la política H70, la semilla `20260925` y 100 réplicas.
5. Ejecutar la comparación. Puede tardar varios minutos.

## Valores de control

| Indicador | MTS100 | H70 |
|---|---|---|
| Inventario terminado medio (m²) | 21.837,81 | 16.181,98 |
| OTIF (%) | 99,77 | 99,55 |
| Plazo medio de entrega (días) | 1,016 | 1,847 |

| Indicador económico | Valor |
|---|---|
| VAN incremental medio (ARS de marzo de 2025) | 2.017.082 |
| IC del 95 % | 1.516.322 – 2.517.842 |
| Pares con VAN negativo | 11 de 100 |
| VAN de la primera réplica | 1.749.094,62 |

Con tres réplicas y la misma semilla, el VAN medio esperado es 1.809.023,90 ARS (control rápido documentado en `sistema_web/VERIFICACION.txt`).

Cualquier cambio de parámetros produce una ejecución nueva e identificada; no corresponde comparar sus resultados con los valores de control.
