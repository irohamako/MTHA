# Arquitectura de MTH-A

## Visión general

MTH-A separa tres capas: **datos e indicadores**, **simulación operativa** y **evaluación económica**. Cada capa puede usarse por separado y todas leen sus parámetros desde archivos, no desde valores escritos en el código.

```
Datos (CSV / JSON) ──► Indicadores deterministas ──► Configuración del caso (JSON)
                                                          │
                     Generador de pedidos fechados ◄──────┤
                                │                         │
                                ▼                         │
                 Simulación de eventos discretos (SimPy) ◄┘
                                │
                                ▼
            Evaluación económica (costos, IVA, capital de trabajo, VAN)
                                │
                                ▼
          Resultados por réplica, diferencias pareadas e intervalos
```

## Módulos

| Módulo | Responsabilidad |
|---|---|
| `herramienta_datos/mtha/analisis.py` | Cálculos deterministas por familia: demanda media, desvío, CV, participación, stock promedio, cobertura, rotación, capital, costo de mantenimiento, carga y holgura MTO. No completa datos faltantes: un dato ausente no se convierte en cero. |
| `herramienta_datos/app.py` | Servidor HTTP local con un token generado en cada inicio; sirve la interfaz web y exporta los resultados. |
| `motor/nucleo/demanda.py` | Genera pedidos fechados: conteo Poisson por mes, tamaño lognormal, grupo y hora de llegada. Una misma realización se comparte entre todas las políticas comparadas. |
| `motor/nucleo/modelo.py` | Simulación por eventos discretos con SimPy: recurso agregado, ventanas de capacidad, lotes que deben caber completos, calidad, despacho, tránsito, reposición de materiales y planificador que solo usa información ya disponible. Mide inventarios como promedio ponderado por el tiempo. |
| `motor/evaluacion.py` | Motor económico: costos variables y fijos, ingresos al entregar, IVA, impuesto bancario, capital de trabajo, valor remanente y VAN incremental. Ejecuta los pares de réplicas en paralelo y calcula intervalos de confianza. |
| `motor/configuracion_operativa.json` | Horizonte, grupos, ventanas, políticas, materiales, edades iniciales, demanda mensual y procedencia de cada parámetro. |
| `motor/parametros_economicos_previos.json` | Base económica: tipo de cambio, salario de referencia, cargas sociales, consumos y precios de energía, materiales y condiciones comerciales. |
| `sistema_web/sistema.py`, `trabajo.py`, `pantalla.html` | Interfaz en el navegador para ejecutar una comparación en segundo plano y descargar los resultados. |
| `aplicacion_escritorio/app.py` | Aplicación de escritorio en Tkinter con nueve secciones: Inicio, Mi proyecto, Demanda, Inventario y capacidad, Simulación (con el recorrido de eventos), Economía, Importar y analizar, Historial y Ayuda. |
| `aplicacion_escritorio/datos.py` | Usuarios locales y proyectos en SQLite; las contraseñas se guardan con PBKDF2 y sal aleatoria. |
| `aplicacion_escritorio/tareas.py` | Ejecuta cada simulación en un proceso separado para que la ventana siga respondiendo. |

## Principios de diseño

- **Parámetros fuera del código**: todo valor del caso vive en archivos de configuración con su procedencia.
- **Comparación justa**: las políticas reciben los mismos pedidos, los mismos estados iniciales y el mismo calendario en cada réplica (números aleatorios comunes).
- **Sin información futura**: el planificador decide solo con los pedidos que ya llegaron.
- **Balances verificables**: materia prima, producción en proceso, producto terminado y tránsito se concilian en cada evento.
- **Trazabilidad**: cada ejecución guarda sus entradas, su semilla y una huella de la configuración.

## Etapas de desarrollo

1. **Calculadora inicial** (interfaz web con Python en el navegador): comparaba MTS y MTH-A, pero recibía como entradas indicadores que debía calcular, como el OTIF y el plazo.
2. **Motor de reglas por eventos**: reglas de reposición, prioridad y liberación de lotes ejecutadas sobre una cola de eventos, con el análisis estructural MICMAC como apoyo al diseño.
3. **Herramienta de datos** (v1.0.0, 13/9/2026): carga y validación de datos por familia e indicadores deterministas, con pruebas unitarias.
4. **Simulador con SimPy**: reloj de simulación, ventanas, materiales y diferencias pareadas; verificado contra el motor anterior.
5. **Motor económico y aplicaciones** (28/9/2026): evaluación económica integrada, sistema web y aplicación de escritorio.

## Adaptación a otra industria

1. Definir la familia de productos y sus grupos con plazos de cliente propios (`grupos`).
2. Cargar la demanda mensual esperada y el tamaño medio y la dispersión de los pedidos (`demanda_mensual`, `parametros`).
3. Ajustar el lote, el rendimiento y el ritmo neto del recurso crítico (`parametros`).
4. Definir las ventanas de capacidad disponibles para la familia (`ventanas`).
5. Definir los materiales por lote, la cobertura y el plazo de abastecimiento (`materiales`).
6. Declarar las políticas a comparar: qué grupos se producen para stock (`politicas`).
7. Reemplazar la base económica por la del nuevo caso (`parametros_economicos_previos.json`).
8. Ejecutar, revisar balances y recorrido de pedidos, y solo después interpretar indicadores.

Cambiar el sector no exige modificar el código mientras el proceso pueda representarse con un recurso agregado, lotes y ventanas. Procesos con varios recursos críticos que compiten entre sí requieren extender `modelo.py`.
